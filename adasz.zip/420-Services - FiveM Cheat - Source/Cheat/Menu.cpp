// language: C++, file: Cheat/Menu.cpp, target: Windows 11, MSVC
// Lua-executor-only menu: resource router, script editor, injector. All feature modules stripped.
#include "Menu.h"
#include <Windows.h>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cmath>
#include <fstream>
#include <filesystem>
#include <commdlg.h>
#include "../Resources.h"
#include "../cfx/resource_manager.h"
#include "../cfx/resource.h"
#include "../lua_exec.hpp"
#include "../Resource/resource_embed.h"

// Singleton accessor (declared in Menu.h)
Menu* Menu::s_pSingleton = nullptr;

Menu* Menu::Get() {
	if (!s_pSingleton)
		s_pSingleton = new Menu();
	return s_pSingleton;
}

#ifndef LUA_SCRIPT_BUF_SIZE
#define LUA_SCRIPT_BUF_SIZE (2 * 1024 * 1024)
#endif
#ifndef LUA_CONSOLE_BUF_SIZE
#define LUA_CONSOLE_BUF_SIZE (256 * 1024)
#endif

static char lua_script_buf[LUA_SCRIPT_BUF_SIZE] = "";
static char lua_console_buf[LUA_CONSOLE_BUF_SIZE] = "";
static int lua_selected_resource = 0;
static wchar_t lua_last_path[MAX_PATH] = L"";
static std::map<std::string, int> lua_exec_counts;
static char lua_res_filter[128] = "";
static std::unordered_map<std::string, double> s_lastStopReq;
static std::unordered_map<std::string, double> s_lastStartReq;
static std::unordered_map<std::string, bool> s_userStopped;
static bool lua_console_autoscroll = true;
static ImFont* g_LuaMonoFont = nullptr;

// Console display lines (mirror of lua_console_buf, bounded for cheap rendering)
static std::vector<std::string> s_consoleLines;
static const size_t kMaxConsoleLines = 400;

static void AppendLuaLog(const char* msg) {
	double t = ImGui::GetTime();
	int h = (int)(t / 3600.0);
	int m = (int)fmod(t / 60.0, 60.0);
	int s = (int)fmod(t, 60.0);
	char line[512];
	_snprintf_s(line, sizeof(line), _TRUNCATE, "[%02d:%02d:%02d] %s\n", h, m, s, msg);
	size_t cur = strlen(lua_console_buf);
	size_t rem = sizeof(lua_console_buf) - cur - 1;
	if (rem > 0) {
		_snprintf_s(lua_console_buf + cur, rem + 1, _TRUNCATE, "%s", line);
	}
	s_consoleLines.emplace_back(line);
	if (s_consoleLines.size() > kMaxConsoleLines)
		s_consoleLines.erase(s_consoleLines.begin(), s_consoleLines.begin() + (s_consoleLines.size() - kMaxConsoleLines));
}

static std::string ReadFileToString(const wchar_t* path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) return {};
    std::string data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    return data;
}

static bool OpenLuaFileDialog(std::wstring& outPath) {
    wchar_t fileName[MAX_PATH] = L"";
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = nullptr;
    ofn.lpstrFilter = L"Lua Files (*.lua)\0*.lua\0All Files (*.*)\0*.*\0";
    ofn.lpstrFile = fileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
    ofn.lpstrDefExt = L"lua";
    if (GetOpenFileNameW(&ofn)) { outPath = fileName; return true; }
    return false;
}

static bool SaveLuaFileDialog(std::wstring& outPath)
{
    wchar_t fileName[MAX_PATH] = L"script.lua";
    OPENFILENAMEW ofn{};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = nullptr;
    ofn.lpstrFilter = L"Lua Files (*.lua)\0*.lua\0All Files (*.*)\0*.*\0";
    ofn.lpstrFile = fileName;
    ofn.nMaxFile = MAX_PATH;
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
    ofn.lpstrDefExt = L"lua";
    if (GetSaveFileNameW(&ofn)) { outPath = fileName; return true; }
    return false;
}

static bool WriteStringToFile(const wchar_t* path, const char* data, size_t len)
{
    if (!path || !data) return false;
    std::ofstream file(path, std::ios::binary | std::ios::trunc);
    if (!file) return false;
    file.write(data, (std::streamsize)len);
    return file.good();
}

static std::vector<fx::fwRefContainer<fx::Resource>> GetResourcesSafe() {
    std::vector<fx::fwRefContainer<fx::Resource>> out;
    Resources::refresh();
    for (const auto& res : Resources::ResourceList) {
        if (res.Pointer) {
            fx::Resource* r = reinterpret_cast<fx::Resource*>(res.Pointer);
            out.emplace_back(r);
        }
    }
    return out;
}

static std::vector<fx::fwRefContainer<fx::Resource>> s_cachedResources;
static double s_lastResRefresh = 0.0;
static const std::vector<fx::fwRefContainer<fx::Resource>>& GetResourcesCached()
{
    if ((ImGui::GetTime() - s_lastResRefresh) > 1.0) {
        s_cachedResources = GetResourcesSafe();
        s_lastResRefresh = ImGui::GetTime();
    }
    return s_cachedResources;
}

static const char* kSafeResAllowlist[] = {
    "monitor",
    "chat",
    "sessionmanager",
    "spawnmanager",
    "baseevents",
    "hardcap",
    "mapmanager",
    "playernames",
    "rconlog",
    "scoreboard",
    "basic-gamemode",
    "citizen-scripting-core",
    "citizen-scripting-lua",
    "fivem",
};

static const char* kSafeResPrefixes[] = {
    "monitor",
    "chat",
    "session",
    "spawn",
    "baseevent",
    "hardcap",
    "mapmanager",
    "playername",
    "rcon",
    "scoreboard",
    "basic",
    "citizen",
    "fivem",
};

static bool equals_icase(const std::string& a, const char* b)
{
    if (!b) return false;
    if (a.size() != strlen(b)) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        char ca = (char)tolower(a[i]);
        char cb = (char)tolower(b[i]);
        if (ca != cb) return false;
    }
    return true;
}

// Name comes from the cached ResourceList (already extracted safely by
// Resources::refresh with zero game reads / vtable calls). Fall back to empty.
static std::string SafeResourceName(const fx::fwRefContainer<fx::Resource>& r)
{
    if (!r.GetRef()) return std::string();
    uintptr_t ptr = (uintptr_t)r.GetRef();
    for (const auto& s : Resources::ResourceList) {
        if (s.Pointer == ptr) return s.Name;
    }
    return std::string();
}

static fx::fwRefContainer<fx::Resource> PickSafeResource()
{
    auto list = GetResourcesCached();
    if (list.empty()) list = GetResourcesSafe();

    for (auto& r : list) {
        if (!r.GetRef()) continue;
        std::string nm = SafeResourceName(r);
        for (auto* allowed : kSafeResAllowlist) {
            if (equals_icase(nm, allowed)) return r;
        }
    }

    for (auto& r : list) {
        if (!r.GetRef()) continue;
        std::string nm = SafeResourceName(r);
        if (nm.empty()) continue;
        std::string low = nm;
        std::transform(low.begin(), low.end(), low.begin(), [](unsigned char c){ return (char)tolower(c); });
        for (auto* pref : kSafeResPrefixes) {
            if (low.find(pref) != std::string::npos) return r;
        }
    }

    return fx::fwRefContainer<fx::Resource>();
}

static inline void SafeLuaEnqueueScript(const std::string& script);
static void TickLuaInjector();
static bool SafeLuaExecOnResourceChunked(const fx::fwRefContainer<fx::Resource>& r, const std::string& script);

static inline std::string WrapLuaScriptForSafeExec(const std::string& body)
{
    std::string wrapped;
    wrapped.reserve(body.size() + 128);
    wrapped += "Citizen.CreateThread(function() Wait(0) local ok,err=pcall(function() ";
    wrapped += body;
    wrapped += " end) if not ok then print('[Pink][Lua error]: '..tostring(err)) end end)";
    return wrapped;
}

static inline std::string Base64Encode(const uint8_t* data, size_t len)
{
    static const char* kB64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    out.reserve((len * 4) / 3 + 4);
    size_t i = 0;
    while (i + 2 < len) {
        uint32_t n = (uint32_t(data[i]) << 16) | (uint32_t(data[i + 1]) << 8) | uint32_t(data[i + 2]);
        out.push_back(kB64[(n >> 18) & 63]);
        out.push_back(kB64[(n >> 12) & 63]);
        out.push_back(kB64[(n >> 6) & 63]);
        out.push_back(kB64[n & 63]);
        i += 3;
    }
    if (i < len) {
        uint32_t n = uint32_t(data[i]) << 16;
        out.push_back(kB64[(n >> 18) & 63]);
        if (i + 1 < len) {
            n |= (uint32_t(data[i + 1]) << 8);
            out.push_back(kB64[(n >> 12) & 63]);
            out.push_back(kB64[(n >> 6) & 63]);
            out.push_back('=');
        } else {
            out.push_back(kB64[(n >> 12) & 63]);
            out.push_back('=');
            out.push_back('=');
        }
    }
    return out;
}

static inline std::string BuildB64ExecPayload(const std::string& script)
{
    std::string b64 = Base64Encode(reinterpret_cast<const uint8_t*>(script.data()), script.size());
    std::string p;
    p.reserve(b64.size() + 512);
    p += "local __b='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'\n";
    p += "local function __d(data) data=data:gsub('[^'..__b..'=]',''); return (data:gsub('.', function(x) if x=='=' then return '' end local r,f='',(__b:find(x,1,true)-1) for i=6,1,-1 do r=r..(f%2^i - f%2^(i-1) > 0 and '1' or '0') end return r end):gsub('%d%d%d?%d?%d?%d?%d?%d?', function(x) if #x~=8 then return '' end local c=0 for i=1,8 do c=c + (x:sub(i,i)=='1' and 2^(8-i) or 0) end return string.char(c) end)) end\n";
    p += "do local _c=[[";
    p += b64;
    p += "]]; local _s=__d(_c); _c=nil; Citizen.CreateThread(function() local ok,err=pcall(function() local fn,e=load(_s); if not fn then error(e) end; fn() end); if not ok then print('[Pink][Lua error]: '..tostring(err)) end end) end";
    return p;
}

static inline std::string LuaEscapeForSingleQuoted(const std::string& src)
{
    std::string out;
    out.reserve(src.size() * 2);
    for (char c : src) {
        switch (c) {
        case '\\': out += "\\\\"; break;
        case '\'': out += "\\'"; break;
        case '\n': out += "\\n"; break;
        case '\r': out += "\\r"; break;
        case '\t': out += "\\t"; break;
        default: out += c; break;
        }
    }
    return out;
}

static void BuildLuaChunkFragments(const std::string& script, size_t chunkSize, std::vector<std::string>& outFragments)
{
    const std::string escaped = LuaEscapeForSingleQuoted(script);
    const size_t total = escaped.size();
    size_t pos = 0;

    outFragments.emplace_back("_PINKC = (_PINKC or '')\n");

    while (pos < total) {
        const size_t len = (total - pos > chunkSize) ? chunkSize : (total - pos);
        std::string stmt;
        stmt.reserve(len + 64);
        stmt += "_PINKC = _PINKC .. '";
        stmt.append(escaped.c_str() + pos, len);
        stmt += "'\n";
        outFragments.emplace_back(std::move(stmt));
        pos += len;
    }

    outFragments.emplace_back(
        "do local _src=_PINKC; _PINKC=nil; Citizen.CreateThread(function() "
        "local ok,err=pcall(function() local fn,e=load(_src); if not fn then error(e) end; fn() end); "
        "if not ok then print('[Pink][Lua error]: '..tostring(err)) end end) end\n");
}

static std::string BuildSingleMessageChunkedPayload(const std::string& script, size_t chunkSize)
{
    const std::string escaped = LuaEscapeForSingleQuoted(script);
    const size_t total = escaped.size();
    size_t pos = 0;
    std::string payload;

    payload.reserve(total + 256);
    payload += "local _t={}; ";
    while (pos < total) {
        const size_t len = (total - pos > chunkSize) ? chunkSize : (total - pos);
        payload += "_t[#_t+1]='";
        payload.append(escaped.c_str() + pos, len);
        payload += "'; ";
        pos += len;
    }
    payload += "local _src=table.concat(_t); _t=nil; "
               "Citizen.CreateThread(function() "
               "local ok,err=pcall(function() local fn,e=load(_src); if not fn then error(e) end; fn() end); "
               "if not ok then print('[Pink][Lua error]: '..tostring(err)) end end)";
    return payload;
}

static bool SafeLuaExecOnResourceChunked(const fx::fwRefContainer<fx::Resource>& r, const std::string& script)
{
    if (!r.GetRef()) return false;
    std::string resName = SafeResourceName(r);
    if (resName.empty()) return false;

    std::string payload = BuildB64ExecPayload(script);

    char dbg[256];
    _snprintf_s(dbg, _countof(dbg), _TRUNCATE, "Chunked(exec one-shot) via '%s': payload %zu bytes", resName.c_str(), payload.size());
    AppendLuaLog(dbg);

    lua_exec_counts[resName] = 0;
    auto inserted = std::make_shared<bool>(false);
    size_t connHandle = r->Runtime.Connect([resName, payload, inserted](std::vector<char>* info){
        int& count = lua_exec_counts[resName];
        if (!*inserted && (count == 4 || count == 6)) {
            info->insert(info->begin(), payload.begin(), payload.end());
            *inserted = true;
        }
        count++;
    });

    r->Stop();
    r->Start();
    r->Runtime.Disconnect(connHandle);

    char logbuf[256];
    _snprintf_s(logbuf, _countof(logbuf), _TRUNCATE, "Executed (chunked one-shot) via '%s'", resName.c_str());
    AppendLuaLog(logbuf);
    return *inserted;
}

static bool SafeLuaExecOnResource(const fx::fwRefContainer<fx::Resource>& r, const std::string& script)
{
    if (!r.GetRef()) return false;
    std::string resName = SafeResourceName(r);
    if (resName.empty()) return false;

    if (script.size() > (128 * 1024)) {
        AppendLuaLog("Script too large (>128KB) — aborted for safety.");
        return false;
    }

    char size_msg[128];
    _snprintf_s(size_msg, _countof(size_msg), _TRUNCATE, "Script size: %zu bytes", script.size());
    AppendLuaLog(size_msg);

    lua_exec_counts[resName] = 0;
    std::string payload = WrapLuaScriptForSafeExec(script) + ";";
    auto inserted = std::make_shared<bool>(false);

    char debug_msg[256];
    _snprintf_s(debug_msg, _countof(debug_msg), _TRUNCATE, "Injecting to '%s': payload %zu chars", resName.c_str(), payload.size());
    AppendLuaLog(debug_msg);

    size_t connHandle = r->Runtime.Connect([resName, payload, inserted](std::vector<char>* info){
        int& count = lua_exec_counts[resName];
        if (!*inserted && (count == 4 || count == 6)) {
            info->insert(info->begin(), payload.begin(), payload.end());
            *inserted = true;
        }
        count++;
    });

    r->Stop();
    r->Start();
    r->Runtime.Disconnect(connHandle);

    char logbuf[256];
    _snprintf_s(logbuf, _countof(logbuf), _TRUNCATE, "Executed via '%s' (inserted=%d)", resName.c_str(), *inserted ? 1 : 0);
    AppendLuaLog(logbuf);
    return *inserted;
}

static bool SafeLuaExecScript(const std::string& script)
{
    auto r = PickSafeResource();
    if (!r.GetRef()) {
        AppendLuaLog("No safe resource available for Lua execution.");
        return false;
    }
    AppendLuaLog("Found safe resource for execution");

    if (script.size() > 1500) {
        return SafeLuaExecOnResourceChunked(r, script);
    }
    return SafeLuaExecOnResource(r, script);
}

static std::vector<std::string> s_luaQueue;
static double s_luaLastEnqueue = 0.0;
static bool s_luaInjectBusy = false;
static double s_luaBusyUntil = 0.0;

static inline void SafeLuaEnqueueScript(const std::string& script)
{
    s_luaQueue.push_back(script);
    s_luaLastEnqueue = ImGui::GetTime();
    char msg[128];
    _snprintf_s(msg, _countof(msg), _TRUNCATE, "Script queued for execution (%zu chars)", script.size());
    AppendLuaLog(msg);
}

static void TickLuaInjector()
{
    if (s_luaQueue.empty()) return;
    if (s_luaInjectBusy && ImGui::GetTime() < s_luaBusyUntil) return;

    std::string batch;
    for (size_t i = 0; i < s_luaQueue.size(); ++i) {
        batch += s_luaQueue[i];
        batch += ";\n";
    }

    char batch_info[256];
    _snprintf_s(batch_info, _countof(batch_info), _TRUNCATE, "Executing batch: %zu items, %zu chars", s_luaQueue.size(), batch.size());
    AppendLuaLog(batch_info);

    if (SafeLuaExecScript(batch)) {
        char msg[128]; _snprintf_s(msg, _TRUNCATE, "Batch executed %zu item(s).", s_luaQueue.size());
        AppendLuaLog(msg);
        s_luaQueue.clear();
        s_luaInjectBusy = true;
        s_luaBusyUntil = ImGui::GetTime() + 0.75;
    } else {
        AppendLuaLog("Failed to execute Lua batch");
    }
}

void Menu::LoadImGui()
{
    if (lua_script_buf[0] == '\0') {
        const char* def = "print(\"Hello world\")";
        strncpy_s(lua_script_buf, def, _TRUNCATE);
    }
	if (ImGui::GetCurrentContext() == nullptr)
		ImGui::CreateContext();

	ui::styles();
	ui::colors();

	ImGuiIO& io = ImGui::GetIO();

	io.ConfigFlags = ImGuiConfigFlags_None;
	io.IniFilename = nullptr;
	io.LogFilename = nullptr;
	ImFontConfig font_config;
	font_config.PixelSnapH = false;
	font_config.FontDataOwnedByAtlas = false;
	font_config.OversampleH = 5;
	font_config.OversampleV = 5;
	font_config.RasterizerMultiply = 1.2f;

	static const ImWchar ranges[] =
	{
		0x0020, 0x00FF,
		0x0400, 0x052F,
		0x2DE0, 0x2DFF,
		0xA640, 0xA69F,
		0xE000, 0xE226,
		0,
	};

	static bool s_fonts_loaded = false;
	if (!s_fonts_loaded) {
		fonts[font].set_data(b_font, sizeof(b_font));
		fonts[fontb].set_data(b_fontb, sizeof(b_fontb));
		fonts[icons].set_data(glyphter, sizeof(glyphter));

		fonts[font].init(16);
		fonts[fontb].init(12);
		fonts[icons].init(16);

		static ImFont* s_fontVerdana = nullptr;
		if (!s_fontVerdana) {
			s_fontVerdana = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\verdana.ttf", 13.0f, &font_config, io.Fonts->GetGlyphRangesDefault());
			if (s_fontVerdana) {
				io.FontDefault = s_fontVerdana;
			}
		}

		if (g_TitleFont == nullptr)
			g_TitleFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoeuib.ttf", 56.0f, &font_config, io.Fonts->GetGlyphRangesDefault());
		if (g_SubTitleFont == nullptr)
			g_SubTitleFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoeui.ttf", 36.0f, &font_config, io.Fonts->GetGlyphRangesDefault());

		if (!g_LuaMonoFont)
			g_LuaMonoFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\consola.ttf", 14.0f, &font_config, io.Fonts->GetGlyphRangesDefault());

		s_fonts_loaded = true;
	}

	{
		ImGuiStyle& s = ImGui::GetStyle();
		s.Colors[ImGuiCol_FrameBg]        = ImVec4(0.04f, 0.04f, 0.04f, 0.82f);
		s.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.06f, 0.06f, 0.06f, 0.90f);
		s.Colors[ImGuiCol_FrameBgActive]  = ImVec4(0.08f, 0.08f, 0.08f, 1.00f);
		s.Colors[ImGuiCol_PopupBg]        = ImVec4(0.06f, 0.06f, 0.06f, 0.94f);
	}

	// ---- Lua tab, page 0: resource router ----
	ui::add_page(0, []() {
		ui::begin_child(sk("Resources"), ImVec2(ImGui::GetContentRegionAvail().x, 0)); {
			ImVec2 avail = ImGui::GetContentRegionAvail();
			float totalW = avail.x;
			float spacing = ImGui::GetStyle().ItemSpacing.x;
			float leftW = totalW * 0.60f;

			ImGui::BeginGroup();
			{
				ImGui::SetNextItemWidth(leftW);
				ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(10, 10, 10, 210));
				ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, IM_COL32(14, 14, 14, 230));
				ImGui::PushStyleColor(ImGuiCol_FrameBgActive, IM_COL32(18, 18, 18, 255));
				ImGui::InputTextWithHint(sk("Filter##res_search"), sk("Filter resources..."), lua_res_filter, IM_ARRAYSIZE(lua_res_filter));
				ImGui::PopStyleColor(3);

				auto resources2 = GetResourcesSafe();
				float baseH = ImGui::GetTextLineHeight() * 15.0f;
				ImVec2 listSize = ImVec2(leftW, baseH);
				ImGui::PushStyleColor(ImGuiCol_ChildBg, IM_COL32(10, 10, 10, 210));
				if (ImGui::BeginListBox(sk("##res_list"), listSize)) {
					for (int i = 0; i < (int)resources2.size(); ++i) {
						if (!resources2[i].GetRef()) continue;
						std::string nameStr = SafeResourceName(resources2[i]);
						if (lua_res_filter[0] != '\0' && nameStr.find(lua_res_filter) == std::string::npos) continue;
						bool isSelected = (lua_selected_resource == i);
						ImGui::PushID(i);
						if (ImGui::Selectable(nameStr.c_str(), isSelected)) {
							lua_selected_resource = i;
						}
						ImGui::PopID();
					}
					ImGui::EndListBox();
				}
				ImGui::PopStyleColor();

				if (lua_selected_resource >= (int)resources2.size()) lua_selected_resource = (int)resources2.size() - 1;
				if (lua_selected_resource < 0 && !resources2.empty()) lua_selected_resource = 0;
			}
			ImGui::EndGroup();

			ImGui::SameLine();

			ImGui::BeginGroup();
			{
				float rightW = totalW - leftW - spacing;
				float baseH = ImGui::GetTextLineHeight() * 9.0f;
				float __detailsW = rightW * 0.60f;
				float __detailsH = baseH * 3.0f;
				ImGui::BeginChild(sk("##res_details"), ImVec2(__detailsW, __detailsH), false, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar);
				auto resources2 = GetResourcesCached();
				bool hasSel = (lua_selected_resource >= 0 && lua_selected_resource < (int)resources2.size());
				if (hasSel) {
					auto r = resources2[lua_selected_resource];
					const bool refOk = r.GetRef();
					std::string nameStr = refOk ? SafeResourceName(r) : std::string();
					bool isStoppedByUser = (!nameStr.empty() && s_userStopped[nameStr]);
					bool isRunning = !isStoppedByUser;
					const char* statusTxt = isRunning ? "Running..." : "Stopped";
					ImGui::Text("Status: %s", statusTxt);

					ImGui::Dummy(ImVec2(0, 6));

					ImGui::BeginDisabled(!refOk || !isStoppedByUser);
					if (ui::modern_button(sk("Start"), ImVec2(ImGui::CalcItemWidth(), ImGui::GetFrameHeight()))) {
						if (r.GetRef()) { r->Start(); if (!nameStr.empty()) s_userStopped[nameStr] = false; }
					}
					ImGui::EndDisabled();

					ImGui::BeginDisabled(!refOk || isStoppedByUser);
					if (ui::modern_button(sk("Stop"), ImVec2(ImGui::CalcItemWidth(), ImGui::GetFrameHeight()))) {
						if (r.GetRef()) { r->Stop(); if (!nameStr.empty()) s_userStopped[nameStr] = true; }
					}
					ImGui::EndDisabled();

					if (ui::modern_button(sk("Restart"), ImVec2(ImGui::CalcItemWidth(), ImGui::GetFrameHeight()))) {
						if (r.GetRef()) { r->Stop(); Sleep(50); r->Start(); if (!nameStr.empty()) s_userStopped[nameStr] = false; }
					}

				} else {
					ImGui::TextDisabled("No resource selected");
				}
				ImGui::Separator();
				ImGui::EndChild();
			}
			ImGui::EndGroup();
		} ui::end_child();

		// ---- Embedded resource status row ----
		ui::begin_child(sk("Embedded"), ImVec2(ImGui::GetContentRegionAvail().x, 0)); {
			ImGui::BeginGroup();
			{
				const char* st = ResourceEmbed::GetStateName();
				const bool ok = (ResourceEmbed::GetState() == ResourceEmbed::State::Executed);
				ImGui::Text("Embedded 420-Services resource: ");
				ImGui::SameLine();
				ImGui::TextColored(ok ? ImVec4(0.3f, 1.0f, 0.4f, 1.0f)
				                       : ImVec4(1.0f, 0.6f, 0.2f, 1.0f), "%s", st);
				if (!ok && ResourceEmbed::GetState() == ResourceEmbed::State::Failed) {
					ImGui::TextDisabled("Last error: %s", ResourceEmbed::GetLastError().c_str());
				}
			}
			ImGui::EndGroup();

			ImGui::SameLine();
			if (ui::modern_button(sk("Run now"), ImVec2(110, 0))) {
				ResourceEmbed::RunNow();
			}
		} ui::end_child();
		});

	// ---- Lua tab, page 1: editor + console ----
	ui::add_page(1, []() {
		ui::begin_child(sk("Lua"), ImVec2(ImGui::GetContentRegionAvail().x, 0)); {
			ImGuiInputTextFlags flags = ImGuiInputTextFlags_AllowTabInput;
			float editorHeight = ImGui::GetTextLineHeight() * 24.0f;
			ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(10, 10, 10, 210));
			ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
			ImGui::BeginChild(sk("##lua_editor"), ImVec2(-1, editorHeight), true, ImGuiWindowFlags_NoScrollbar);
			{
				ImGui::PushFont(g_LuaMonoFont ? g_LuaMonoFont : ImGui::GetFont());
				ImGui::InputTextMultiline(sk("##lua_script"), lua_script_buf, IM_ARRAYSIZE(lua_script_buf), ImVec2(-1, -1), flags);
				ImGui::PopFont();
			}
			ImGui::EndChild();
			ImGui::PopStyleVar();
			ImGui::PopStyleColor();

			ImGui::Dummy(ImVec2(0, 6));
			if (ui::modern_button(sk("Execute"), ImVec2(90, 0))) {
				std::string script(lua_script_buf);
				if (IsLuaReady()) {
					DirectLuaExec(script);
					AppendLuaLog("[Pink] DirectLua: OK");
				} else {
					AppendLuaLog("[Pink] DirectLua not ready, fallback RPC");
					SafeLuaExecScript(script);
				}
			}
			ImGui::SameLine();
			if (ui::modern_button(sk("Clear"), ImVec2(90, 0))) { lua_script_buf[0] = '\0'; }
			ImGui::SameLine();
			if (ui::modern_button(sk("Open Lua"), ImVec2(90, 0))) {
				std::wstring pathW;
				if (OpenLuaFileDialog(pathW)) {
					std::string data = ReadFileToString(pathW.c_str());
					if (!data.empty()) {
						strncpy_s(lua_script_buf, data.c_str(), _TRUNCATE);
						wcsncpy_s(lua_last_path, pathW.c_str(), _TRUNCATE);
						AppendLuaLog("Opened script.");
					}
				}
			}
			ImGui::SameLine();
			if (ui::modern_button(sk("Save As"), ImVec2(90, 0))) {
				std::wstring pathW;
				if (SaveLuaFileDialog(pathW)) {
					size_t len = strlen(lua_script_buf);
					if (WriteStringToFile(pathW.c_str(), lua_script_buf, len)) {
						wcsncpy_s(lua_last_path, pathW.c_str(), _TRUNCATE);
						AppendLuaLog("Saved script.");
					}
				}
			}
			ImGui::SameLine();
			if (ui::modern_button(sk("Copy"), ImVec2(80, 0))) {
				ImGui::SetClipboardText(lua_script_buf);
				AppendLuaLog("Copied to clipboard.");
			}
			ImGui::SameLine();
			if (ui::modern_button(sk("Paste"), ImVec2(80, 0))) {
				const char* clip = ImGui::GetClipboardText();
				if (clip) {
					strncpy_s(lua_script_buf, clip, _TRUNCATE);
					AppendLuaLog("Pasted from clipboard.");
				}
			}
			ImGui::SameLine();
			ImGui::Checkbox(sk("Auto-scroll console"), &lua_console_autoscroll);
			ImGui::SameLine();
			{
				auto r = PickSafeResource();
				std::string rn = (r.GetRef() ? SafeResourceName(r) : std::string());
				ImGui::TextDisabled("Target: %s", rn.empty() ? "<none>" : rn.c_str());
			}

			// console
			ImGui::Dummy(ImVec2(0, 6));
			ImGui::PushStyleColor(ImGuiCol_FrameBg, IM_COL32(10, 10, 10, 210));
			ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
			float consoleHeight = ImGui::GetContentRegionAvail().y;
			ImGui::BeginChild(sk("##lua_console"), ImVec2(-1, consoleHeight), true, ImGuiWindowFlags_NoScrollbar);
			{
				static size_t s_consoleLen = 0;
				if (lua_console_autoscroll && s_consoleLines.size() != s_consoleLen) {
					ImGui::SetScrollHereY(1.0f);
					s_consoleLen = s_consoleLines.size();
				}
				ImGui::PushFont(g_LuaMonoFont ? g_LuaMonoFont : ImGui::GetFont());
				ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 1));
				for (const auto& ln : s_consoleLines) {
					ImGui::TextUnformatted(ln.c_str());
				}
				ImGui::PopStyleVar();
				ImGui::PopFont();
			}
			ImGui::EndChild();
			ImGui::PopStyleVar();
			ImGui::PopStyleColor();

			// menu strip: hotkey + input block + unload
			ImGui::Dummy(ImVec2(0, 6));
			ImGui::Separator();
			ui::begin_child(sk("Menu")); {
				ui::binder(sk("Menu Key"), &globals.menu.hotkey);
				ImGui::SameLine();
				ImGui::Checkbox(sk("Block Input"), &globals.menu_settings.block_input);
				ImGui::SameLine();
				if (ui::modern_button(sk("Unload"), ImVec2(90, 0))) {
					globals.menu.unload_requested = true;
				}
			} ui::end_child();
		} ui::end_child();
		});
}

void Menu::Load() {
	TickLuaInjector();

	static float menu_anim = 0.0f;
	static float bounce_anim = 0.0f;
	float dt = ImGui::GetIO().DeltaTime;
	float target = globals.menu.opened ? 1.0f : 0.0f;

	menu_anim = ImLerp(menu_anim, target, 12.0f * dt);

	if (target > 0.5f && menu_anim > 0.85f) {
		bounce_anim = ImLerp(bounce_anim, 1.0f, 8.0f * dt);
	} else {
		bounce_anim = ImLerp(bounce_anim, 0.0f, 15.0f * dt);
	}

	float cubic_out = 1.0f - (1.0f - menu_anim) * (1.0f - menu_anim) * (1.0f - menu_anim);
	float bounce_offset = bounce_anim * 0.08f * sinf(bounce_anim * 3.14159f * 2.0f);
	float eased_menu_anim = ImClamp(cubic_out + bounce_offset, 0.0f, 1.0f);

	ImGui::GetIO().MouseDrawCursor = globals.menu.opened;
	if (menu_anim > 0.01f) {
		ImDrawList* __bg = ImGui::GetBackgroundDrawList();
		ImVec2 __disp = ImGui::GetIO().DisplaySize;
		__bg->AddRectFilled(ImVec2(0, 0), __disp, ImGui::GetColorU32(ImVec4(0, 0, 0, 0.03f * eased_menu_anim)));

		ImGui::PushStyleVar(ImGuiStyleVar_Alpha, eased_menu_anim);
		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 0, 0 });
		ImGui::Begin(sk("Settings"), 0, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBackground);
		{
			ImGui::PopStyleVar();
			ImGui::SetWindowSize(ui::size);

			{
				const ImGuiStyle& style = ImGui::GetStyle();
				ImVec2 s = ImVec2(ImGui::GetWindowSize().x - style.WindowPadding.x * 2, ImGui::GetWindowSize().y - style.WindowPadding.y * 2);
				ImVec2 p = ImVec2(ImGui::GetWindowPos().x + style.WindowPadding.x, ImGui::GetWindowPos().y + style.WindowPadding.y);
				ImDrawList* draw = ImGui::GetWindowDrawList();
				ImU32 main_col = ImGui::GetColorU32(ImGuiCol_Scheme);

				draw->PushClipRect(ImVec2(p.x, p.y), ImVec2(p.x + s.x * eased_menu_anim, p.y + s.y), true);

				draw->AddRectFilled(ImVec2(p.x, p.y), ImVec2(p.x + s.x, p.y + s.y), ImColor(8, 8, 8), 4);
				draw->AddRect(ImVec2(p.x + 1, p.y + 1), ImVec2(p.x + s.x - 1, p.y + s.y - 1), ImColor(27, 27, 27, 255), 4.5f);

				draw->AddLine(ImVec2(p.x, p.y + s.y - 27), ImVec2(p.x + s.x, p.y + s.y - 27), ImColor(27, 27, 27, 255));
				draw->AddLine(ImVec2(p.x, p.y + 25), ImVec2(p.x + s.x, p.y + 25), ImColor(27, 27, 27, 255));

				draw->AddRect(ImVec2(p.x + 10.0f, p.y + 35.3f), ImVec2(p.x + 10.0f + 120.0f, p.y + s.y - 36.85f), ImColor(26, 26, 26, 255));

				int fade_line_count = 60;
				float fade_stop = s.x;
				float center_point = fade_stop / 2.0f;
				for (int i = 0; i < fade_line_count; i++)
				{
					float alpha = 1.0f - (i * (1.0f / fade_line_count));
					ImVec2 start_right = ImVec2(p.x + fade_stop - i * (center_point / fade_line_count), p.y + 25);
					ImVec2 end_right = ImVec2(p.x + fade_stop - (i + 1) * (center_point / fade_line_count), p.y + 25);
					ImVec4 c = ImGui::GetStyle().Colors[ImGuiCol_Scheme];
					c.w *= alpha;
					draw->AddLine(start_right, end_right, ImGui::GetColorU32(c));
				}

				draw->AddText(ImVec2(p.x + 9.5f, p.y + 7.f), main_col, sk("comeback.xyz").decrypt());
				draw->AddText(ImVec2(p.x + 9.5f, p.y + s.y - 22.f), ImColor(255, 255, 255, 100), sk("Build:").decrypt());
				draw->AddText(ImVec2(p.x + 41.f, p.y + s.y - 22.f), (ImU32)main_col, sk("Live").decrypt());

				const char* rb = sk("@lennox.s26").decrypt();
				ImVec2 rb_sz = ImGui::CalcTextSize(rb);
				draw->AddText(ImVec2(p.x + s.x - rb_sz.x - 12.f, p.y + s.y - 22.f), (ImU32)main_col, rb);

				draw->PopClipRect();
			}

			ImGui::SetCursorPos(ImVec2(112, 10));
			ImGui::BeginGroup();
			ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(12, 0));
			for (int i = 0; i < ui::tabs.size(); ++i) {
				ui::tab(i);
				ImGui::SameLine();
			}
			ImGui::PopStyleVar();
			ImGui::EndGroup();

			if (!ui::tabs[ui::cur_page].m_subtabs.empty()) {
				for (int i = 0; i < ui::tabs[ui::cur_page].m_subtabs.size(); ++i) {
					ImGui::SetCursorPosY(54.0f + i * 25.0f);
					ImGui::SetCursorPosX(30.0f);
					ui::subtab(i);
				}
			}

			ImGui::SetCursorPosY(38.0f);
			ImGui::SetCursorPosX(122.0f);

			{
				float slide_x = (1.0f - eased_menu_anim) * 24.0f;
				float slide_y = (1.0f - (ui::content_anim * ui::content_anim2)) * 8.0f;
				ImVec2 cur = ImGui::GetCursorPos();
				ImGui::SetCursorPos(ImVec2(cur.x + slide_x, cur.y + slide_y));
			}

			ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 20, 20 });

			ImGui::PushStyleVar(ImGuiStyleVar_Alpha, eased_menu_anim * ui::content_anim * ui::content_anim2);
			ImGui::BeginChild(sk("main"), { 0, -1 }, 0, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_AlwaysUseWindowPadding);
			{
				ImDrawList* cd = ImGui::GetWindowDrawList();
				ImVec2 cpos = ImGui::GetWindowPos();
				ImVec2 csize = ImGui::GetWindowSize();
				float reveal = ImSaturate(eased_menu_anim * (0.3f + 0.7f * ui::content_anim) * (0.3f + 0.7f * ui::content_anim2));
				cd->PushClipRect(cpos, ImVec2(cpos.x + csize.x * reveal, cpos.y + csize.y), true);

				ui::render_page();

				cd->PopClipRect();
			}
			ImGui::EndChild();
			ImGui::PopStyleVar(2);
		}
		ImGui::End();
		ImGui::PopStyleVar();

		ui::handle_alpha_anim();
	}
}