#include "core.h"
#include <cmath>

Core* Core::m_pSingleton = nullptr;

// Inline replacements for D3DXMatrixTranspose / D3DXVec3Transform.
// Avoids a runtime dependency on the legacy D3DX library.
static void MatrixTranspose(D3DXMATRIX& out, const D3DXMATRIX& in)
{
    out._11 = in._11; out._12 = in._21; out._13 = in._31; out._14 = in._41;
    out._21 = in._12; out._22 = in._22; out._23 = in._32; out._24 = in._42;
    out._31 = in._13; out._32 = in._23; out._33 = in._33; out._34 = in._43;
    out._41 = in._14; out._42 = in._24; out._43 = in._34; out._44 = in._44;
}

static D3DXVECTOR4 Vec3Transform(const D3DXVECTOR3& v, const D3DXMATRIX& m)
{
    D3DXVECTOR4 out;
    out.x = m._11 * v.x + m._21 * v.y + m._31 * v.z + m._41;
    out.y = m._12 * v.x + m._22 * v.y + m._32 * v.z + m._42;
    out.z = m._13 * v.x + m._23 * v.y + m._33 * v.z + m._43;
    out.w = m._14 * v.x + m._24 * v.y + m._34 * v.z + m._44;
    return out;
}

ImVec2 Core::W2S(Vector3 pos)
{
    uint64_t viewport = *(uint64_t*)(Address::Get()->s_pViewPort);
    D3DXMATRIX matrix = *(D3DXMATRIX*)(viewport + 0x24C);

    D3DXVECTOR3 screenPosition;

    MatrixTranspose(matrix, matrix);
    D3DXVECTOR4 vectorX = D3DXVECTOR4(matrix._21, matrix._22, matrix._23, matrix._24);
    D3DXVECTOR4 vectorY = D3DXVECTOR4(matrix._31, matrix._32, matrix._33, matrix._34);
    D3DXVECTOR4 vectorZ = D3DXVECTOR4(matrix._41, matrix._42, matrix._43, matrix._44);

    screenPosition.x = (vectorX.x * pos.x) + (vectorX.y * pos.y) + (vectorX.z * pos.z) + vectorX.w;
    screenPosition.y = (vectorY.x * pos.x) + (vectorY.y * pos.y) + (vectorY.z * pos.z) + vectorY.w;
    screenPosition.z = (vectorZ.x * pos.x) + (vectorZ.y * pos.y) + (vectorZ.z * pos.z) + vectorZ.w;

    if (screenPosition.z <= 0.1f)
        return ImVec2();

    screenPosition.z = 1.0f / screenPosition.z;
    screenPosition.x *= screenPosition.z;
    screenPosition.y *= screenPosition.z;

    screenPosition.x += ImGui::GetIO().DisplaySize.x / 2 + (int)(0.5f * screenPosition.x * ImGui::GetIO().DisplaySize.x + 0.5f);
    screenPosition.y = ImGui::GetIO().DisplaySize.y / 2 - (int)(0.5f * screenPosition.y * ImGui::GetIO().DisplaySize.y + 0.5f);

    return ImVec2(screenPosition.x, screenPosition.y);
}
float Core::Pythag(const ImVec2& a, const ImVec2& b)
{
    float dx = a.x - b.x;
    float dy = a.y - b.y;
    return std::sqrt(dx * dx + dy * dy);
}

Vector3 Core::BoneVec(const uint64_t cPed, int boneid)
{
    D3DXMATRIX matrix = *(D3DXMATRIX*)(cPed + 0x60);
    D3DXVECTOR3 bone = *(D3DXVECTOR3*)(cPed + Address::Get()->m_pBoneOffset + boneid * 0x10);

    D3DXVECTOR4 transform = Vec3Transform(bone, matrix);

    return Vector3(transform.x, transform.y, transform.z);
}
DWORD64 Core::GetCamera()
{
    return *(DWORD64*)(Address::Get()->s_pViewAngles);
}

uint8_t Core::get_owner_id(uint64_t net_object) {
    return *(uint8_t*)(net_object + 0x49); 
}

bool Core::set_network_id_can_migrate(uint64_t net_object, bool toggle) {
    auto word_004E = *(uint16_t*)(net_object + 0x4E); 
    if (!toggle)
        *(uint16_t*)(net_object + 0x4E) = word_004E | 1; 
    else
        *(uint16_t*)(net_object + 0x4E) = word_004E & ~1; 
    return true;
}

bool Core::set_network_id_exists_on_all_machines(uint64_t net_object, bool toggle) {
    auto word_004E = *(uint16_t*)(net_object + 0x4E); 
    if (toggle)
        *(uint16_t*)(net_object + 0x4E) = word_004E | 8; 
    else
        *(uint16_t*)(net_object + 0x4E) = word_004E & ~8; 
    return true;
}

bool Core::network_request_control_of_network_id(uint64_t net_object, uint64_t local_net_object) {
    *(uint8_t*)(net_object + 0x49) = get_owner_id(local_net_object); 
    *(uint8_t*)(net_object + 0x4A) = 0xFF; 
    *(uint8_t*)(net_object + 0x4B) = 0; 
    return true;
}

void Core::network_request_control_of_entity(uint64_t entity, uint64_t localplayer) {
    uint64_t entity_net_object = *(uint64_t*)(entity + 0xD0); 
    uint64_t local_net_object = *(uint64_t*)(localplayer + 0xD0); 
    set_network_id_can_migrate(entity_net_object, true);
    set_network_id_exists_on_all_machines(entity_net_object, true);
    network_request_control_of_network_id(entity_net_object, local_net_object);
}