#pragma once

#include "includes.h"

class cGlobals {
public:
	class cMenu {
	public:
		c_key hotkey{ VK_INSERT };
		bool opened = true;
		bool unload_requested = false;
		bool unloaded = false;
	};
	cMenu menu;

	struct cMenuSettings {
		bool block_input = false;
	};
	cMenuSettings menu_settings;
};
inline cGlobals globals;