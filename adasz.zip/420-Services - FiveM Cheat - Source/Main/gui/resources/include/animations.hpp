#pragma once

//
// animations.hpp - per-widget animation state, allocation-free.
//
// The helpers below used function-local `static std::map/std::unordered_map`
// objects (magic statics). Those are constructed lazily behind a thread-safe init
// guard whose bookkeeping lives in CRT/TLS state. This module is mapped by hand
// and its entry point is invoked directly, so that guard could report "already
// initialised" while the storage was still the zero-filled .bss image. For an
// associative container that state is unrecoverable: find()/operator[]
// dereferences a null node and faults with C0000005 at +0x8.
//
// The tables here have no constructor, no destructor, no allocator, no vtable,
// no TLS access and no guard variable. They are valid the moment the section is
// mapped, whichever thread arrives first.
//

#include "pod_anim.h"
#include <vector>
#include <cmath>
#include <cstdlib>

// Keyed state for anim_obj. Semantics match the map it replaces: the first call
// for an id stores `arg`, every later call returns that same slot by reference.
// A per-slot used flag keeps "not yet seeded" distinct from a default-built T.
template < typename T, int N >
struct AnimObjTable {
	unsigned char used[ N ] = {};
	ImGuiID       keys[ N ] = {};
	T             values[ N ] = {};

	T& slot( ImGuiID id, const T& seed ) {
		if ( id == 0 )
			id = 1;

		unsigned idx = static_cast< unsigned >( id * 2654435761u ) & ( N - 1 );

		for ( int probe = 0; probe < 4; ++probe ) {
			if ( !used[ idx ] ) {
				used[ idx ]  = 1;
				keys[ idx ]  = id;
				values[ idx ] = seed;
				return values[ idx ];
			}
			if ( keys[ idx ] == id )
				return values[ idx ];

			idx = ( idx + 1 ) & ( N - 1 );
		}

		// Saturated island: re-seed the current slot instead of spinning.
		used[ idx ]  = 1;
		keys[ idx ]  = id;
		values[ idx ] = seed;
		return values[ idx ];
	}
};

// Step index state for anim2 - the value is only ever a position in `steps`.
template < int N >
struct AnimStepTable {
	unsigned char used[ N ] = {};
	ImGuiID       keys[ N ] = {};
	int           values[ N ] = {};

	int& slot( ImGuiID id ) {
		if ( id == 0 )
			id = 1;

		unsigned idx = static_cast< unsigned >( id * 2654435761u ) & ( N - 1 );

		for ( int probe = 0; probe < 4; ++probe ) {
			if ( !used[ idx ] ) {
				used[ idx ]  = 1;
				keys[ idx ]  = id;
				values[ idx ] = 0;
				return values[ idx ];
			}
			if ( keys[ idx ] == id )
				return values[ idx ];

			idx = ( idx + 1 ) & ( N - 1 );
		}

		used[ idx ] = 1;
		keys[ idx ] = id;
		return values[ idx ];
	}
};

template < typename T >
inline T& anim_obj( const char* id, int seed, T arg ) {
	ImGuiID im_id = ImHashStr( id, 0, seed );

	static AnimObjTable< T, 256 > map;
	return map.slot( im_id, arg );
}

template < typename T >
inline T anim( T v, T min, T max, bool state, float speed = 14.f ) {
	return ImLerp( v, state ? max : min, speed * ImGui::GetIO( ).DeltaTime );
}

template < typename T >
inline T anim2( const char* id, int seed, T v, std::vector< T > steps, bool state, float speed = 19.f ) {
	ImGuiID im_id = ImHashStr( id, 0, seed );

	static AnimStepTable< 256 > map;
	int& step = map.slot( im_id );

	// Empty step list: nothing to interpolate towards.
	if ( steps.empty( ) ) {
		step = 0;
		return v;
	}

	const int last = static_cast< int >( steps.size( ) ) - 1;

	// Clamp on every use. A vector shorter than a previously stored index must not
	// turn into an out-of-bounds read; the old code indexed unconditionally.
	if ( step < 0 )
		step = 0;
	else if ( step > last )
		step = last;

	if ( std::abs( steps[ static_cast< size_t >( step ) ] - v ) < 0.01f ) {
		if ( step < last )
			step++;
	}

	if ( !state )
		step = 0;

	return ImLerp( v, steps[ static_cast< size_t >( step ) ], speed * ImGui::GetIO( ).DeltaTime );
}

inline ImColor col_anim( ImColor inactive, ImColor active, float anim ) {
	return ImGui::ColorConvertFloat4ToU32( ImLerp( inactive.Value, active.Value, anim ) );
}
