#pragma once
#include <imgui.h>

// ---------------------------------------------------------------------------
// pod_anim - keyed per-widget animation state with NO runtime construction.
//
// Why this exists:
//   The menu render path (ui::tab / ui::subtab / ui::button) used function-local
//   `static std::map<ImGuiID, T>` objects for fade/lerp/ripple state. Function-
//   local statics are "magic statics": they are constructed lazily on first use
//   and guarded by thread-safe init machinery whose epoch/init state lives in
//   CRT thread-local storage.
//
//   This DLL is not loaded by the Windows loader. It is mapped by hand and its
//   entry point is invoked directly, so the CRT's thread/init bookkeeping does
//   not match what those guards assume. On a first touch from a thread whose
//   state the guard machine does not expect, the guard can take the "already
//   initialized" path while the storage is still the zero-filled .bss image.
//   For an std::map that state is catastrophic but not obviously so: the
//   object pointer looks valid, _Myhead._Left/_Right/_Parent are all null, so
//   find()/operator[] dereferences a null node:
//
//       mov rcx, qword ptr [rsi+8]     ; -> 0x0000000000000008, AV
//
//   That is exactly the fault this replaced (cn.dll+0x155B8, ui::tab, taken
//   from the present hook).
//
//   This container is a plain POD table with a compile-time size. No
//   constructor, no destructor, no allocator, no vtable, no TLS access and no
//   guard variable - it is valid in the .bss image the instant the section is
//   mapped, whichever thread arrives first.
//
// Semantics match the animation use case: operator[] returns a reference to
// zero-initialised state for `id`, creating the entry on demand. N must be
// a power of two and comfortably larger than the number of live animated
// widgets; probe collisions reuse a slot rather than chaining, which is the
// right trade for transient visual state and keeps the path allocation-free.
// ---------------------------------------------------------------------------
template <typename T, int N>
class PodAnimTable
{
    static_assert(N >= 8 && ((N & (N - 1)) == 0), "PodAnimTable<N> requires N to be a power of two");

public:
    // Keyed access. Creates the entry (zeroed) if absent. Never faults: the
    // table is a fixed-size array in the image, indexed by a masked hash.
    T& operator[](ImGuiID id)
    {
        if (id == 0)
            id = 1;

        unsigned slot = static_cast<unsigned>(id * 2654435761u) & (N - 1);

        for (int probe = 0; probe < kMaxProbe; ++probe)
        {
            // An empty slot or the same id: claim it.
            if (keys_[slot] == id || keys_[slot] == 0)
            {
                keys_[slot] = id;
                return vals_[slot];
            }
            slot = (slot + 1) & (N - 1);
        }

        // Saturated island: overwrite instead of spinning or growing.
        keys_[slot] = id;
        return vals_[slot];
    }

private:
    static const int kMaxProbe = 4;
    ImGuiID keys_[N] = {};
    T       vals_[N] = {};
};
