#include "Resources.h"
#include "Memory.h"
#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <mutex>
#include <windows.h>
#include "./Cheat/addr/address.h"
#include "./Main/encrypt/skStr.h"
#include "./Main/Scanner.h"
uint64_t ResourceHandle = (uint64_t)GetModuleHandleA(sk("citizen-resources-core.dll"));
uintptr_t Resources::BaseAddr, Resources::ResourceListEntry, Resources::ResourceScanAddress;
int Resources::chosenResource = -1;
typedef uint64_t(*TerminateResource_t)(uintptr_t pResourcePointer);
TerminateResource_t TerminateResource = nullptr;
uintptr_t fetchPath(uintptr_t address) {
    __try {
        return *(uintptr_t*)(address);
    }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        return NULL;
    }
}

char fetchChar(uintptr_t address) {
    __try {
        return *reinterpret_cast<char*>(address);
    }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        return NULL;
    }
}

uint32_t fetchU32(uintptr_t address) {
    __try {
        return *(uint32_t*)(address);
    }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        return 0;
    }
}

uintptr_t fetchPtr(uintptr_t address) {
    __try {
        return *(uintptr_t*)(address);
    }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        return 0;
    }
}

// POD-only guard: verifies the pointer looks like a live C++ object (committed
// memory + a readable vtable pointer) before we ever AddRef/call through it.
// Garbage list entries can pass the path/state string checks; this stops them
// from reaching GetResourcesSafe's fwRefContainer AddRef (a vtable call).
static bool IsPlausibleObject(uintptr_t p) {
    __try {
        if (!p) return false;
        MEMORY_BASIC_INFORMATION mbi;
        if (!VirtualQuery(reinterpret_cast<LPCVOID>(p), &mbi, sizeof(mbi))) return false;
        if (mbi.State != MEM_COMMIT || (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD))) return false;

        uintptr_t vtbl = *(uintptr_t*)p;
        if (!vtbl) return false;
        if (!VirtualQuery(reinterpret_cast<LPCVOID>(vtbl), &mbi, sizeof(mbi))) return false;
        if (mbi.State != MEM_COMMIT || (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD))) return false;
        return true;
    }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        return false;
    }
}
std::string extractString(uintptr_t Addr) {
    const int maxLength = 256;
    char buffer[maxLength] = { 0 };
    int readCount = 0;

    MEMORY_BASIC_INFORMATION mbi;
    if (VirtualQuery(reinterpret_cast<LPCVOID>(Addr), &mbi, sizeof(mbi)) == 0) {
        return "[ERROR]";
    }

    while (readCount < maxLength - 1) {
        char ch = fetchChar(Addr + readCount);
        if (ch == NULL) break;

        buffer[readCount] = ch;
        if (ch == '\0') break;
        readCount++;
    }

    return std::string(buffer);
}

bool offsetsInitialized = false;
bool terminationOffsetsInitialized = false;

void Resources::terminate(uintptr_t ResourcePointer) {
    if (!terminationOffsetsInitialized) {
        TerminateResource = reinterpret_cast<TerminateResource_t>(Scanner::Get()->Scan("citizen-resources-core.dll", "48 83 EC ? C7 81", NULL, NULL));
    }

    HANDLE threadHandle = CreateRemoteThread(GetCurrentProcess(), NULL, 0, (LPTHREAD_START_ROUTINE)TerminateResource, (LPVOID)ResourcePointer, 0, NULL);
    CloseHandle(threadHandle);
}

// POD-only helper: no objects requiring unwinding, so __try is legal here.
// Resolves the resource registry base from citizen-resources-core.dll once.
// Never retried per frame: a failed scan stays failed for this process.
bool Resources::InitResourceOffsets()
{
    __try {
        ResourceScanAddress = Scanner::Get()->Scan("citizen-resources-core.dll", "48 8B 05 ? ? ? ? 48 8D 14 F0", NULL, NULL);
        if (!ResourceScanAddress) return false;
        int disp = *(int*)(ResourceScanAddress + 3);
        ResourceListEntry = *(uintptr_t*)(ResourceScanAddress + disp + 7);
        return ResourceListEntry != 0;
    }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        ResourceListEntry = 0;
        return false;
    }
}

void Resources::refresh() {
    if (!offsetsInitialized) {
        // Scan ONCE per process, never per frame.
        offsetsInitialized = true;
        ResourceListEntry = 0;
        if (!InitResourceOffsets()) return;
    }

    if (!ResourceListEntry) return;

    // Every raw game read below goes through the guarded POD helpers
    // (fetchPtr / fetchPath / fetchU32 / extractString), so this walk can
    // never raise an AV even if the list base is garbage.
    size_t currentListSize = ResourceList.size();
    size_t currentIndex = 0;

    for (size_t i = 0; i < 500; i++) {
        uintptr_t resourcePointer = fetchPtr(ResourceListEntry + (i * 8U));

        if (!resourcePointer) continue;

        // Reject anything that isn't a live C++ object BEFORE we AddRef or
        // call through its vtable downstream in GetResourcesSafe.
        if (!IsPlausibleObject(resourcePointer)) continue;

        uintptr_t pathPointer = fetchPath(resourcePointer + 0xF0);
        if (!pathPointer) continue;

        std::string fullPath = extractString(pathPointer);
        if (fullPath.empty() || fullPath.find("resources:/") == std::string::npos) continue;

        std::string resourceName = fullPath.substr(11, fullPath.length() - 12);
        uint32_t resourceState = fetchU32(resourcePointer + 0x118);
        if (resourceState < eResourceState::Uninitialized || resourceState > eResourceState::Stopping) continue;

        resourceStruct resourceEntry;
        resourceEntry.Pointer = resourcePointer;
        resourceEntry.Path = fullPath;
        resourceEntry.Name = resourceName;
        resourceEntry.State = static_cast<eResourceState>(resourceState);

        if (currentIndex < currentListSize) {
            ResourceList[currentIndex] = resourceEntry;
        }
        else {
            ResourceList.push_back(resourceEntry);
        }

        currentIndex++;
    }

    if (currentIndex < currentListSize) ResourceList.resize(currentIndex);
}
