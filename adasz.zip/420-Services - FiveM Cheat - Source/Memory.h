#pragma once
// Memory.h — compatibility stub.
// The original tree referenced this header from Resources.cpp but shipped no
// definition and no symbol from it is used. Kept so the project compiles.