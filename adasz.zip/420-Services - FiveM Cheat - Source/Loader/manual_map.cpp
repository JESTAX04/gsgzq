// language: C++, file: Loader/manual_map.cpp, target: Windows 11, MSVC x64
// Loader-side manual mapper (quiet path).
//
//  1. map image into target as RW (not RWX)
//  2. write headers + sections
//  3. hand off to the PIC payload on a hijacked existing thread
//  4. payload wipes headers, resolves imports, applies relocs, drops RWX,
//     calls DllMain, then parks and signals completion in args
//  5. restore the hijacked thread's original context
//
// A hijacked thread that is blocked in a kernel wait will not pick up a
// rewritten Rip until that syscall returns, so dispatch sweeps the target's
// threads and keeps the first one that actually starts the payload.
// CreateRemoteThread remains the fallback.
#include "manual_map.h"
#include "shellcode.h"

#include <windows.h>
#include <winnt.h>
#include <tlhelp32.h>
#include <cstring>
#include <cstddef>
#include <vector>

namespace
{
    DWORD SectionProtect(DWORD characteristics)
    {
        const bool X = (characteristics & IMAGE_SCN_MEM_EXECUTE) != 0;
        const bool W = (characteristics & IMAGE_SCN_MEM_WRITE)   != 0;
        if (X && W) return PAGE_EXECUTE_READWRITE;
        if (X)      return PAGE_EXECUTE_READ;
        if (W)      return PAGE_READWRITE;
        return PAGE_READONLY;
    }

    void CollectThreads(DWORD pid, std::vector<DWORD>& out)
    {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (snap == INVALID_HANDLE_VALUE)
            return;

        THREADENTRY32 te;
        te.dwSize = sizeof(te);
        if (Thread32First(snap, &te))
        {
            do
            {
                if (te.th32OwnerProcessID == pid && te.th32ThreadID != GetCurrentThreadId())
                    out.push_back(te.th32ThreadID);
            } while (Thread32Next(snap, &te));
        }
        CloseHandle(snap);
    }

    enum class Attempt { NotStarted, Running, Finished };

    // Try to run the payload on one thread. Returns Finished once the payload
    // signaled completion, Running if it started but did not finish in time,
    // NotStarted if the thread never picked it up.
    Attempt TryHijack(HANDLE hProc, DWORD tid, void* scRemote, void* argsRemote,
                      MapperDiag* diag, DWORD* outResult)
    {
        HANDLE hThread = OpenThread(
            THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT |
            THREAD_SET_CONTEXT | THREAD_QUERY_INFORMATION,
            FALSE, tid);
        if (!hThread)
            return Attempt::NotStarted;

        if (SuspendThread(hThread) == (DWORD)-1)
        {
            CloseHandle(hThread);
            return Attempt::NotStarted;
        }

        CONTEXT orig;
        orig.ContextFlags = CONTEXT_FULL;
        if (!GetThreadContext(hThread, &orig))
        {
            ResumeThread(hThread);
            CloseHandle(hThread);
            return Attempt::NotStarted;
        }

        // Never relocate the stack: a private allocation is outside the TEB's
        // [StackLimit, StackBase] range and the first exception unwind or
        // loader stack check fast-fails the process. Carve a frame below the
        // current RSP instead, which stays on the thread's real stack.
        const uintptr_t savedRsp = (uintptr_t)orig.Rsp;
        if (savedRsp < 0x10000)
        {
            ResumeThread(hThread);
            CloseHandle(hThread);
            return Attempt::NotStarted;
        }

        const uintptr_t scratch = (savedRsp - 0x800) & ~(uintptr_t)0xF;
        BYTE zero = 0;
        WriteProcessMemory(hProc, (void*)(scratch - 8), &zero, 1, nullptr);

        CONTEXT ctx = orig;
        ctx.Rsp = scratch - 8;
        ctx.Rip = (DWORD64)scRemote;
        ctx.Rcx = (DWORD64)argsRemote;

        if (diag) diag->hijackStep = 1;

        if (!SetThreadContext(hThread, &ctx))
        {
            ResumeThread(hThread);
            CloseHandle(hThread);
            return Attempt::NotStarted;
        }
        if (diag) diag->hijackStep = 2;

        ResumeThread(hThread);
        if (diag) diag->hijackStep = 3;

        // Short probe first: did this thread take the payload at all?
        bool started = false;
        bool done = false;
        const DWORD probeEnd = GetTickCount() + 700;
        while (GetTickCount() < probeEnd)
        {
            LONG r = 0, d = 0;
            ReadProcessMemory(hProc, (BYTE*)argsRemote + offsetof(SCodeArgs, ready), &r, sizeof(r), nullptr);
            ReadProcessMemory(hProc, (BYTE*)argsRemote + offsetof(SCodeArgs, done), &d, sizeof(d), nullptr);
            if (r) { started = true; if (diag) diag->ready = r; }
            if (d) { done = true; break; }
            if (WaitForSingleObject(hProc, 0) == WAIT_OBJECT_0) break;
            Sleep(5);
        }

        Attempt result = Attempt::NotStarted;

        if (done)
        {
            result = Attempt::Finished;
        }
        else if (started)
        {
            // Payload is running on this thread; give it room to finish.
            const DWORD deadline = GetTickCount() + 25000;
            while (GetTickCount() < deadline)
            {
                LONG s = 0, d = 0;
                if (ReadProcessMemory(hProc, (BYTE*)argsRemote + offsetof(SCodeArgs, stage), &s, sizeof(s), nullptr) && s && diag)
                    diag->stage = s;
                if (ReadProcessMemory(hProc, (BYTE*)argsRemote + offsetof(SCodeArgs, done), &d, sizeof(d), nullptr) && d)
                {
                    done = true;
                    break;
                }
                if (WaitForSingleObject(hProc, 0) == WAIT_OBJECT_0) break;
                Sleep(10);
            }
            result = done ? Attempt::Finished : Attempt::Running;
        }

        if (done)
        {
            ReadProcessMemory(hProc,
                (BYTE*)argsRemote + offsetof(SCodeArgs, result),
                outResult, sizeof(*outResult), nullptr);
        }

        // Always restore the thread's original context before letting go.
        SuspendThread(hThread);
        SetThreadContext(hThread, &orig);
        ResumeThread(hThread);
        CloseHandle(hThread);

        return result;
    }
}

DWORD ManualMapDll(DWORD pid, const void* blob, size_t blobSize,
                   MapperDiag* diag, bool forceCrt)
{
    if (diag)
        *diag = MapperDiag{};

    if (!blob || blobSize < sizeof(IMAGE_DOS_HEADER))
        return MM_ERR_BAD_PE;

    const BYTE* img = static_cast<const BYTE*>(blob);

    const IMAGE_DOS_HEADER* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(img);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0 ||
        dos->e_lfanew + sizeof(IMAGE_NT_HEADERS) > blobSize)
        return MM_ERR_BAD_PE;

    const IMAGE_NT_HEADERS* nt =
        reinterpret_cast<const IMAGE_NT_HEADERS*>(img + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE)
        return MM_ERR_BAD_PE;
    if (nt->FileHeader.Machine != IMAGE_FILE_MACHINE_AMD64)
        return MM_ERR_NOT_X64;

    const DWORD  sizeOfImage = nt->OptionalHeader.SizeOfImage;
    const DWORD  sizeOfHead  = nt->OptionalHeader.SizeOfHeaders;
    const uintptr_t prefBase = nt->OptionalHeader.ImageBase;
    const DWORD  entryRva    = nt->OptionalHeader.AddressOfEntryPoint;

    HANDLE hProc = OpenProcess(
        PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ |
        PROCESS_QUERY_INFORMATION | PROCESS_SUSPEND_RESUME,
        FALSE, pid);
    if (!hProc)
        return MM_ERR_OPEN_PROCESS;

    // --- image: RW while staging, RWX is never handed to the loader ---
    void* remoteBase = VirtualAllocEx(hProc, nullptr, sizeOfImage,
        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remoteBase)
    {
        CloseHandle(hProc);
        return MM_ERR_ALLOC_IMAGE;
    }

    const size_t headBytes = (sizeOfHead < blobSize) ? sizeOfHead : blobSize;
    if (!WriteProcessMemory(hProc, remoteBase, img, headBytes, nullptr))
    {
        VirtualFreeEx(hProc, remoteBase, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return MM_ERR_WRITE_HEADERS;
    }

    struct Span { DWORD va; DWORD vs; DWORD ch; };
    std::vector<Span> spans;

    const IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++)
    {
        DWORD rawSize = sec[i].SizeOfRawData;
        DWORD rawPtr  = sec[i].PointerToRawData;
        if (rawSize == 0)
            continue;
        if (rawPtr + rawSize > blobSize)
        {
            VirtualFreeEx(hProc, remoteBase, 0, MEM_RELEASE);
            CloseHandle(hProc);
            return MM_ERR_WRITE_SECTION;
        }
        if (!WriteProcessMemory(hProc,
                static_cast<BYTE*>(remoteBase) + sec[i].VirtualAddress,
                img + rawPtr, rawSize, nullptr))
        {
            VirtualFreeEx(hProc, remoteBase, 0, MEM_RELEASE);
            CloseHandle(hProc);
            return MM_ERR_WRITE_SECTION;
        }
        spans.push_back(Span{ sec[i].VirtualAddress,
                              sec[i].Misc.VirtualSize ? sec[i].Misc.VirtualSize
                                                      : sec[i].SizeOfRawData,
                              sec[i].Characteristics });
    }

    // --- payload + args staging ---
    const BYTE* scData = nullptr;
    size_t      scSize = 0;
    if (!GetShellcodeData(&scData, &scSize) || !scData || scSize == 0)
    {
        VirtualFreeEx(hProc, remoteBase, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return MM_ERR_NO_SHELLCODE;
    }

    SCodeArgs args = {};
    args.imageBase     = reinterpret_cast<uintptr_t>(remoteBase);
    args.delta         = args.imageBase - prefBase;
    args.entryRva      = entryRva;
    args.sizeOfHeaders = sizeOfHead;

    void* argsRemote = VirtualAllocEx(hProc, nullptr, sizeof(SCodeArgs),
        MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!argsRemote)
    {
        VirtualFreeEx(hProc, remoteBase, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return MM_ERR_ALLOC_ARGS;
    }
    if (!WriteProcessMemory(hProc, argsRemote, &args, sizeof(SCodeArgs), nullptr))
    {
        VirtualFreeEx(hProc, argsRemote, 0, MEM_RELEASE);
        VirtualFreeEx(hProc, remoteBase, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return MM_ERR_WRITE_ARGS;
    }

    void* scRemote = VirtualAllocEx(hProc, nullptr, scSize,
        MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!scRemote)
    {
        VirtualFreeEx(hProc, argsRemote, 0, MEM_RELEASE);
        VirtualFreeEx(hProc, remoteBase, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return MM_ERR_ALLOC_SHELLCODE;
    }
    if (!WriteProcessMemory(hProc, scRemote, scData, scSize, nullptr))
    {
        VirtualFreeEx(hProc, scRemote, 0, MEM_RELEASE);
        VirtualFreeEx(hProc, argsRemote, 0, MEM_RELEASE);
        VirtualFreeEx(hProc, remoteBase, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return MM_ERR_WRITE_SHELLCODE;
    }

    DWORD oldProt = 0;
    VirtualProtectEx(hProc, scRemote, scSize, PAGE_EXECUTE_READ, &oldProt);

    // --- dispatch ---
    DWORD result = 0;
    bool ran = false;

    if (!forceCrt)
    {
        std::vector<DWORD> tids;
        CollectThreads(pid, tids);

        for (DWORD tid : tids)
        {
            Attempt a = TryHijack(hProc, tid, scRemote, argsRemote, diag, &result);
            if (a == Attempt::Finished)
            {
                ran = true;
                if (diag) diag->dispatch = 1;
                break;
            }
            if (a == Attempt::Running)
            {
                // Payload is live on this thread but slow; do not start a
                // second copy, just wait it out.
                if (diag) diag->dispatch = 1;
                break;
            }
        }
    }

    if (!ran)
    {
        HANDLE hNew = CreateRemoteThread(hProc, nullptr, 0,
            static_cast<LPTHREAD_START_ROUTINE>(scRemote), argsRemote, 0, nullptr);
        if (hNew)
        {
            WaitForSingleObject(hNew, 30000);
            LONG flag = 0;
            ReadProcessMemory(hProc,
                (BYTE*)argsRemote + offsetof(SCodeArgs, done),
                &flag, sizeof(flag), nullptr);
            if (flag)
            {
                ReadProcessMemory(hProc,
                    (BYTE*)argsRemote + offsetof(SCodeArgs, result),
                    &result, sizeof(result), nullptr);
                ran = true;
                if (diag) diag->dispatch = 2;
            }

            LONG exitFlag = 1;
            WriteProcessMemory(hProc,
                (BYTE*)argsRemote + offsetof(SCodeArgs, exitFlag),
                &exitFlag, sizeof(exitFlag), nullptr);
            WaitForSingleObject(hNew, 5000);
            CloseHandle(hNew);
        }
    }

    // Snapshot diagnostics while the args block is still mapped.
    if (diag)
    {
        ReadProcessMemory(hProc, (BYTE*)argsRemote + offsetof(SCodeArgs, ready),
                          &diag->ready, sizeof(diag->ready), nullptr);
        ReadProcessMemory(hProc, (BYTE*)argsRemote + offsetof(SCodeArgs, stage),
                          &diag->stage, sizeof(diag->stage), nullptr);
        ReadProcessMemory(hProc, (BYTE*)argsRemote + offsetof(SCodeArgs, result),
                          &diag->result, sizeof(diag->result), nullptr);
    }

    VirtualFreeEx(hProc, scRemote, 0, MEM_RELEASE);
    VirtualFreeEx(hProc, argsRemote, 0, MEM_RELEASE);

    // Tighten section protections (the payload already did this; this covers
    // the CRT path and any zero-sized section).
    if (ran && result == 1)
    {
        for (const Span& s : spans)
        {
            if (!s.vs) continue;
            VirtualProtectEx(hProc, static_cast<BYTE*>(remoteBase) + s.va,
                             s.vs, SectionProtect(s.ch), &oldProt);
        }
    }

    CloseHandle(hProc);

    if (!ran)
        return MM_ERR_TIMEOUT;
    if (result == 1)
        return 0;
    if (result == 0)
        return MM_ERR_ENTRY_FALSE;
    return result;
}