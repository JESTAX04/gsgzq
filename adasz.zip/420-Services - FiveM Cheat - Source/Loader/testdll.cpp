// Minimal manual-map test target: DllMain writes a marker and returns TRUE.
// No threads, no hooks, no game deps — isolates the mapper from the cheat DLL.
#include <windows.h>

static void Marker(const char* s)
{
    char path[MAX_PATH];
    DWORD n = GetEnvironmentVariableA("USERPROFILE", path, MAX_PATH);
    if (!n || n >= MAX_PATH - 32)
        return;
    lstrcatA(path, "\\Desktop\\maptest.txt");

    HANDLE h = CreateFileA(path, FILE_APPEND_DATA, FILE_SHARE_READ,
                           nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (h == INVALID_HANDLE_VALUE)
        return;

    SetFilePointer(h, 0, nullptr, FILE_END);
    DWORD w = 0;
    WriteFile(h, s, (DWORD)lstrlenA(s), &w, nullptr);
    WriteFile(h, "\r\n", 2, &w, nullptr);
    CloseHandle(h);
}

BOOL WINAPI DllMain(HMODULE, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        Marker("ATTACH: DllMain ran");
        Marker("Second write: imports ok");
    }
    return TRUE;
}
