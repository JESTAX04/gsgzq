#pragma once
#include <windows.h>
#include <cstddef>
#include <cstdint>

// Shared between loader (fills it) and shellcode (reads/writes it). Both sides
// compile this header, so field offsets are identical.
//
// The payload runs on a *hijacked* existing thread; it signals completion
// through `done`/`result` instead of a thread exit code, and the loader then
// restores the original thread context.
struct SCodeArgs
{
    uintptr_t       imageBase;      // remote base of the mapped image
    uintptr_t       delta;          // remoteBase - preferredImageBase
    DWORD           entryRva;       // RVA of DllMain
    DWORD           sizeOfHeaders;  // header region to wipe after parsing

    volatile LONG   done;           // payload sets 1 when finished
    volatile LONG   result;         // 1 = DllMain TRUE, else failure code
    volatile LONG   ready;          // payload sets 1 once it has started
    volatile LONG   exitFlag;       // loader sets 1 to let a CRT worker return
    volatile LONG   stage;          // progress marker for failure diagnosis
};

// Loader-side diagnostics filled in by ManualMapDll on failure.
struct MapperDiag
{
    LONG ready;
    LONG stage;
    LONG result;
    LONG dispatch;      // 1 = hijack, 2 = CreateRemoteThread, 0 = neither ran
    LONG hijackStep;    // 1=thread found 2=suspended 3=ctx read 4=ctx set 5=resumed
    LONG ctxRipOk;      // readback: Rip == payload entry
    LONG ctxRcxOk;      // readback: Rcx == args pointer
};

// Pointer + length of the PIC payload inside this EXE (.scode section).
bool GetShellcodeData(const BYTE** outPtr, size_t* outSize);