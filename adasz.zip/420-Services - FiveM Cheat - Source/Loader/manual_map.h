#pragma once
#include <windows.h>
#include <cstddef>
#include <cstdint>

struct MapperDiag;

// Manual-maps a raw PE image (DLL) into the target process and runs its
// entry point via the PIC shellcode payload (Loader/shellcode.cpp).
//
// Returns:
//   0                    success — entry point returned TRUE
//   0x100+               loader-side failure (see codes below)
//   2..9                 shellcode stage failure (see ScodeMain)
//   0xFFFF               unknown
//
// forceCrt skips the thread-hijack path (diagnostic isolation).
DWORD ManualMapDll(DWORD pid, const void* blob, size_t blobSize,
                   MapperDiag* diag = nullptr, bool forceCrt = false);

enum : DWORD
{
    MM_ERR_OPEN_PROCESS      = 0x101,
    MM_ERR_WOW64             = 0x102,
    MM_ERR_BAD_PE            = 0x103,
    MM_ERR_NOT_X64           = 0x104,
    MM_ERR_ALLOC_IMAGE       = 0x105,
    MM_ERR_WRITE_HEADERS     = 0x106,
    MM_ERR_WRITE_SECTION     = 0x107,
    MM_ERR_NO_SHELLCODE      = 0x108,
    MM_ERR_ALLOC_ARGS        = 0x109,
    MM_ERR_WRITE_ARGS        = 0x10A,
    MM_ERR_ALLOC_SHELLCODE   = 0x10B,
    MM_ERR_WRITE_SHELLCODE   = 0x10C,
    MM_ERR_CREATE_THREAD     = 0x10D,
    MM_ERR_ENTRY_FALSE       = 0x10E,
    MM_ERR_THREAD_CRASHED    = 0x10F,
    MM_ERR_TIMEOUT           = 0x110,
};