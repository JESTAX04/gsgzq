// language: C++, file: Loader/loader.cpp, target: Windows 11, MSVC x64
// 420-Services loader — full EXE, single-file build.
// The cheat DLL is embedded in this EXE (embedded_dll.h) and manual-mapped
// into the target — no DLL ever exists on disk and it never appears in the
// target's module list. Optionally reads an external DLL via -dll, or uses
// the legacy LoadLibrary path via -inject.
//
// Usage:
//   loader.exe                      auto-wait for GTA5.exe, manual-map embedded cn.dll
//   loader.exe -dll C:\path\cn.dll  manual-map an external DLL file
//   loader.exe -inject C:\cn.dll    legacy LoadLibrary injection (module is listed)
//   loader.exe -launch              start FiveM, then auto-inject when the game spawns
//   loader.exe -pid 1234            target a specific PID
//   loader.exe -timeout 300         max seconds to wait for the process (default 900)
//   loader.exe -altname GTA5_ai.exe target a specific process name (exact match)
//
// Beta FiveM builds (FiveM_bXXXX_GTAProcess.exe) are detected automatically.

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#define NOMINMAX
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <shellapi.h>
#include <shlobj.h>

#include <cstdio>
#include <cstring>
#include <cstdarg>
#include <string>
#include <vector>
#include <fstream>

#include "manual_map.h"
#include "shellcode.h"
#include "embedded_dll.h"

#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "shell32.lib")

// ---------------------------------------------------------------------------
static std::ofstream g_log;
static void Log(const char* fmt, ...)
{
    char buf[2048];
    va_list args;
    va_start(args, fmt);
    vsnprintf_s(buf, _TRUNCATE, fmt, args);
    va_end(args);

    SYSTEMTIME st;
    GetLocalTime(&st);
    char ts[64];
    sprintf_s(ts, "[%02d:%02d:%02d.%03d] ", st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);

    printf("%s%s\n", ts, buf);
    fflush(stdout);

    if (g_log.is_open())
        g_log << ts << buf << std::endl;
}

static void LogW(const wchar_t* fmt, ...)
{
    wchar_t wbuf[1024];
    va_list args;
    va_start(args, fmt);
    _vsnwprintf_s(wbuf, _TRUNCATE, fmt, args);
    va_end(args);

    char mbuf[2048];
    WideCharToMultiByte(CP_UTF8, 0, wbuf, -1, mbuf, sizeof(mbuf), nullptr, nullptr);
    Log("%s", mbuf);
}

// ---------------------------------------------------------------------------
static bool g_altName = false;
static bool g_launchFiveM = false;
static bool g_legacyInject = false;
static std::wstring g_dllPath;
static std::wstring g_procName = L"GTA5.exe";
static DWORD g_targetPid = 0;
static int g_timeoutSec = 900;
static bool g_useHijack = false;   // experimental; -hijack enables the sweep

static bool ParseArgs(int argc, wchar_t** argv)
{
    for (int i = 1; i < argc; ++i)
    {
        std::wstring a = argv[i];
        auto next = [&](std::wstring& out) -> bool
        {
            if (i + 1 >= argc) return false;
            out = argv[++i];
            return true;
        };

        if (a == L"-dll")                        { if (!next(g_dllPath)) return false; }
        else if (a == L"-launch")                { g_launchFiveM = true; }
        else if (a == L"-pid")                   { std::wstring v; if (!next(v)) return false; g_targetPid = (DWORD)_wtoi(v.c_str()); }
        else if (a == L"-timeout")               { std::wstring v; if (!next(v)) return false; g_timeoutSec = _wtoi(v.c_str()); }
        else if (a == L"-hijack")                { g_useHijack = true; }
        else if (a == L"-altname")               { std::wstring v; if (!next(v)) return false; g_procName = v; }
        else if (a == L"-inject")                { if (!next(g_dllPath)) return false; g_legacyInject = true; }
        else if (a == L"-h" || a == L"-help" || a == L"/?")
        {
            Log("Usage: loader.exe [-dll <path>] [-inject <path>] [-launch] [-pid <pid>] [-timeout <sec>] [-altname <exe>] [-hijack]");
            return false;
        }
        else
        {
            Log("Unknown argument: %S", a.c_str());
            return false;
        }
    }
    return true;
}

// ---------------------------------------------------------------------------
static bool EnableDebugPrivilege()
{
    HANDLE hToken;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
        return false;

    TOKEN_PRIVILEGES tp;
    LUID luid;
    bool ok = false;
    if (LookupPrivilegeValue(nullptr, SE_DEBUG_NAME, &luid))
    {
        tp.PrivilegeCount = 1;
        tp.Privileges[0].Luid = luid;
        tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        ok = AdjustTokenPrivileges(hToken, FALSE, &tp, sizeof(tp), nullptr, nullptr) &&
             GetLastError() == ERROR_SUCCESS;
    }
    CloseHandle(hToken);
    return ok;
}

static bool IsWow64(HANDLE proc)
{
    BOOL wow64 = FALSE;
    typedef BOOL(WINAPI* IsWow64Process_t)(HANDLE, PBOOL);
    auto fn = (IsWow64Process_t)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "IsWow64Process2");
    if (fn)
    {
        USHORT procMach = 0, nativeMach = 0;
        typedef BOOL(WINAPI* IsWow64Process2_t)(HANDLE, USHORT*, USHORT*);
        if (((IsWow64Process2_t)fn)(proc, &procMach, &nativeMach))
            return procMach != 0 && procMach != nativeMach;
        return FALSE;
    }
    auto fn1 = (IsWow64Process_t)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "IsWow64Process");
    return fn1 ? fn1(proc, &wow64) && wow64 : FALSE;
}

// ---------------------------------------------------------------------------
// Matches the target game process. Exact match against -altname (default
// GTA5.exe), plus automatic detection of FiveM beta builds, whose game
// process carries the build number: FiveM_bXXXX_GTAProcess.exe.
static bool IsTargetProcess(const wchar_t* name)
{
    if (_wcsicmp(name, g_procName.c_str()) == 0)
        return true;

    // FiveM beta: prefix "FiveM_b" + digits + "_GTAProcess.exe"
    const wchar_t* prefix = L"FiveM_b";
    const wchar_t* suffix = L"_GTAProcess.exe";
    const size_t pLen = 7;                       // wcslen(L"FiveM_b")
    const size_t sLen = wcslen(suffix);
    const size_t len = wcslen(name);

    if (len > pLen + sLen &&
        _wcsnicmp(name, prefix, pLen) == 0 &&
        _wcsicmp(name + len - sLen, suffix) == 0)
    {
        // middle must be the build number (digits)
        bool digits = true;
        for (size_t i = pLen; i < len - sLen; i++)
            if (name[i] < L'0' || name[i] > L'9') { digits = false; break; }
        return digits;
    }
    return false;
}

static DWORD FindProcessPid(const std::wstring& procName)
{
    DWORD pid = 0;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return 0;

    PROCESSENTRY32W pe;
    pe.dwSize = sizeof(pe);
    if (Process32FirstW(snap, &pe))
    {
        do
        {
            if (IsTargetProcess(pe.szExeFile))
            {
                pid = pe.th32ProcessID;
                break;
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

// ---------------------------------------------------------------------------
static bool InjectDll(DWORD pid, const std::wstring& dllPath)
{
    HANDLE hProc = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
    if (!hProc)
    {
        Log("OpenProcess(%lu) failed: %lu", pid, GetLastError());
        return false;
    }

    if (IsWow64(hProc))
    {
        Log("Target is 32-bit — loader is x64. Refusing.");
        CloseHandle(hProc);
        return false;
    }

    // Remote string
    size_t pathBytes = (dllPath.size() + 1) * sizeof(wchar_t);
    void* remote = VirtualAllocEx(hProc, nullptr, pathBytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote)
    {
        Log("VirtualAllocEx failed: %lu", GetLastError());
        CloseHandle(hProc);
        return false;
    }

    if (!WriteProcessMemory(hProc, remote, dllPath.c_str(), pathBytes, nullptr))
    {
        Log("WriteProcessMemory failed: %lu", GetLastError());
        VirtualFreeEx(hProc, remote, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return false;
    }

    HMODULE hK32 = GetModuleHandleW(L"kernel32.dll");
    LPVOID loadLib = GetProcAddress(hK32, "LoadLibraryW");
    if (!loadLib)
    {
        Log("GetProcAddress(LoadLibraryW) failed: %lu", GetLastError());
        VirtualFreeEx(hProc, remote, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return false;
    }

    HANDLE hThread = CreateRemoteThread(hProc, nullptr, 0,
        (LPTHREAD_START_ROUTINE)loadLib, remote, 0, nullptr);
    if (!hThread)
    {
        Log("CreateRemoteThread failed: %lu", GetLastError());
        VirtualFreeEx(hProc, remote, 0, MEM_RELEASE);
        CloseHandle(hProc);
        return false;
    }

    Log("Injection thread running (pid %lu)...", pid);
    WaitForSingleObject(hThread, 15000);

    DWORD exitCode = 0;
    GetExitCodeThread(hThread, &exitCode);
    CloseHandle(hThread);

    VirtualFreeEx(hProc, remote, 0, MEM_RELEASE);
    CloseHandle(hProc);

    if (exitCode == 0)
    {
        Log("LoadLibraryW returned NULL (HMODULE 0)");
        return false;
    }

    Log("LoadLibraryW returned HMODULE 0x%p", (void*)(uintptr_t)exitCode);
    return true;
}

// ---------------------------------------------------------------------------
static bool IsModuleLoaded(DWORD pid, const std::wstring& dllName)
{
    HANDLE hProc = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    if (!hProc)
        return false;

    HMODULE mods[1024];
    DWORD needed = 0;
    bool found = false;
    if (EnumProcessModules(hProc, mods, sizeof(mods), &needed))
    {
        int count = needed / sizeof(HMODULE);
        for (int i = 0; i < count; ++i)
        {
            wchar_t name[MAX_PATH];
            if (GetModuleBaseNameW(hProc, mods[i], name, MAX_PATH) &&
                _wcsicmp(name, dllName.c_str()) == 0)
            {
                found = true;
                break;
            }
        }
    }
    CloseHandle(hProc);
    return found;
}

// ---------------------------------------------------------------------------
static void LaunchFiveM()
{
    // Preferred: local FiveM install path.
    wchar_t localAppData[MAX_PATH];
    if (SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, SHGFP_TYPE_CURRENT, localAppData) == S_OK)
    {
        std::wstring fivem = std::wstring(localAppData) + L"\\FiveM\\FiveM.exe";
        if (GetFileAttributesW(fivem.c_str()) != INVALID_FILE_ATTRIBUTES)
        {
            LogW(L"Launching FiveM: %s", fivem.c_str());
            HINSTANCE r = ShellExecuteW(nullptr, L"open", fivem.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
            if ((intptr_t)r > 32)
                return;
            Log("ShellExecute on FiveM.exe failed (%lld); falling back to URL protocol", (intptr_t)r);
        }
    }

    // Fallback: FiveM:// URL protocol.
    HINSTANCE r = ShellExecuteW(nullptr, L"open", L"FiveM://connect/", nullptr, nullptr, SW_SHOWNORMAL);
    if ((intptr_t)r > 32)
    {
        Log("FiveM launch requested via protocol.");
        return;
    }
    Log("FiveM launch failed — start FiveM manually. (%lld)", (intptr_t)r);
}

// ---------------------------------------------------------------------------
static bool ReadFileBytes(const std::wstring& path, std::vector<BYTE>& out)
{
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) return false;
    std::streampos end = f.tellg();
    f.seekg(0, std::ios::beg);
    out.resize((size_t)end);
    if (end > 0) f.read((char*)out.data(), end);
    return f.good() || (size_t)end == out.size();
}

// pink_trace.txt on the user's Desktop is written by the cheat on attach
// (DLL_PROCESS_ATTACH, InitThread, etc). Used as the manual-map beacon since
// a manually-mapped module never appears in the target's module list.
static std::wstring PinkTracePath()
{
    wchar_t profile[MAX_PATH];
    if (GetEnvironmentVariableW(L"USERPROFILE", profile, MAX_PATH) == 0)
        return L"";
    return std::wstring(profile) + L"\\Desktop\\pink_trace.txt";
}

static DWORD64 FileSizeW(const std::wstring& path)
{
    WIN32_FILE_ATTRIBUTE_DATA fad;
    if (!GetFileAttributesExW(path.c_str(), GetFileExInfoStandard, &fad))
        return 0;
    return ((DWORD64)fad.nFileSizeHigh << 32) | fad.nFileSizeLow;
}

static const char* MapErrorName(DWORD code)
{
    switch (code)
    {
    case 0:                     return "success";
    case MM_ERR_OPEN_PROCESS:   return "OpenProcess failed";
    case MM_ERR_WOW64:          return "target is 32-bit";
    case MM_ERR_BAD_PE:         return "not a valid PE";
    case MM_ERR_NOT_X64:        return "DLL is not x64";
    case MM_ERR_ALLOC_IMAGE:    return "VirtualAllocEx(image) failed";
    case MM_ERR_WRITE_HEADERS:  return "failed to write headers";
    case MM_ERR_WRITE_SECTION:  return "failed to write a section";
    case MM_ERR_NO_SHELLCODE:   return "no mapper payload in EXE";
    case MM_ERR_ALLOC_ARGS:     return "VirtualAllocEx(args) failed";
    case MM_ERR_WRITE_ARGS:     return "failed to write args";
    case MM_ERR_ALLOC_SHELLCODE:return "VirtualAllocEx(shellcode) failed";
    case MM_ERR_WRITE_SHELLCODE:return "failed to write shellcode";
    case MM_ERR_CREATE_THREAD:  return "CreateRemoteThread failed";
    case MM_ERR_ENTRY_FALSE:    return "DllMain returned FALSE";
    case MM_ERR_THREAD_CRASHED: return "payload thread crashed";
    case MM_ERR_TIMEOUT:        return "payload never signaled completion";
    case 2:                     return "shellcode: bad args";
    case 3:                     return "shellcode: bad DOS header";
    case 4:                     return "shellcode: bad NT header";
    case 5:                     return "shellcode: kernel32 not found";
    case 6:                     return "shellcode: LoadLibraryA/GetProcAddress not found";
    case 7:                     return "shellcode: LoadLibraryA failed for an import";
    case 8:                     return "shellcode: GetProcAddress failed for an import";
    default:                    return "unknown mapper failure";
    }
}

// ---------------------------------------------------------------------------
int wmain(int argc, wchar_t** argv)
{
    SetConsoleTitleW(L"420-Services Loader");
    EnableDebugPrivilege();

    // log file next to the exe
    {
        wchar_t exeDir[MAX_PATH];
        GetModuleFileNameW(nullptr, exeDir, MAX_PATH);
        wchar_t* slash = wcsrchr(exeDir, L'\\');
        if (slash) *slash = L'\0';
        std::wstring logPath = std::wstring(exeDir) + L"\\loader.log";
        g_log.open(logPath, std::ios::app);
    }

    Log("=== 420-Services Loader ===");
    Log("Time: %s", __TIMESTAMP__);

    if (!ParseArgs(argc, argv))
        return 1;

    // Resolve DLL payload: external file if -dll/-inject, else embedded.
    std::vector<BYTE> externalBytes;
    const BYTE* payload = nullptr;
    size_t payloadSize = 0;

    if (!g_dllPath.empty())
    {
        if (GetFileAttributesW(g_dllPath.c_str()) == INVALID_FILE_ATTRIBUTES)
        {
            LogW(L"Cheat DLL not found: %s", g_dllPath.c_str());
            return 1;
        }
        if (!ReadFileBytes(g_dllPath, externalBytes) || externalBytes.empty())
        {
            LogW(L"Failed to read DLL: %s", g_dllPath.c_str());
            return 1;
        }
        payload = externalBytes.data();
        payloadSize = externalBytes.size();
        LogW(L"DLL: %s (%zu bytes)", g_dllPath.c_str(), payloadSize);
    }
    else
    {
        payload = g_embeddedDll;
        payloadSize = g_embeddedDllSize;
        Log("DLL: embedded (%zu bytes, manual map)", payloadSize);
    }
    LogW(L"Target process: %s", g_procName.c_str());

    // Enable SeDebugPrivilege for access to the game process.
    if (EnableDebugPrivilege())
        Log("SeDebugPrivilege enabled");
    else
        Log("SeDebugPrivilege unavailable (running as admin not required, but helps)");

    if (g_launchFiveM)
        LaunchFiveM();

    // Wait loop.
    if (g_targetPid == 0)
    {
        Log("Waiting for %S (or FiveM_b*_GTAProcess.exe)... (timeout %ds)", g_procName.c_str(), g_timeoutSec);
        int waited = 0;
        while (g_timeoutSec <= 0 || waited < g_timeoutSec)
        {
            g_targetPid = FindProcessPid(g_procName);
            if (g_targetPid != 0)
                break;
            Sleep(1000);
            waited++;
            if (waited % 10 == 0)
                Log("... still waiting (%ds)", waited);
        }

        if (g_targetPid == 0)
        {
            Log("Timed out waiting for %S.", g_procName.c_str());
            return 2;
        }
        Log("Found %S with PID %lu", g_procName.c_str(), g_targetPid);
    }

    // Verify the process is alive, then inject.
    HANDLE hCheck = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, g_targetPid);
    if (!hCheck)
    {
        Log("Cannot open PID %lu: %lu", g_targetPid, GetLastError());
        return 3;
    }
    CloseHandle(hCheck);

    if (g_legacyInject)
    {
        // Legacy path: LoadLibrary injection (module appears in the list).
        Log("Legacy LoadLibrary injection into PID %lu...", g_targetPid);
        if (!InjectDll(g_targetPid, g_dllPath))
        {
            Log("Injection failed.");
            return 4;
        }
        std::wstring dllName = g_dllPath.substr(g_dllPath.find_last_of(L"\\") + 1);
        Sleep(2000);
        if (IsModuleLoaded(g_targetPid, dllName))
            Log("Module %S confirmed loaded.", dllName.c_str());
        else
            Log("Module %S not found in module list — check pink_trace.txt on the Desktop.", dllName.c_str());
    }
    else
    {
        // Manual map: embedded (or -dll) bytes, no disk, no module entry.
        DWORD64 beforeTrace = FileSizeW(PinkTracePath());
        Log("Manual-mapping into PID %lu...", g_targetPid);
        MapperDiag diag = {};
        DWORD res = ManualMapDll(g_targetPid, payload, payloadSize, &diag, !g_useHijack);
        if (res != 0)
        {
            Log("Manual map failed: %s (0x%X)", MapErrorName(res), res);
            Log("  dispatch=%ld (1=hijack 2=crt)  hijackStep=%ld  ctxRipOk=%ld ctxRcxOk=%ld  payloadStarted=%ld  stage=%ld  result=%ld",
                diag.dispatch, diag.hijackStep, diag.ctxRipOk, diag.ctxRcxOk,
                diag.ready, diag.stage, diag.result);
            return 4;
        }
        Log("Entry point returned TRUE — DllMain attached.");

        // Confirm the cheat's own init thread fired (pink_trace grows).
        bool beacon = false;
        for (int i = 0; i < 10 && !beacon; ++i)
        {
            Sleep(300);
            beacon = FileSizeW(PinkTracePath()) > beforeTrace;
        }
        if (beacon)
            Log("Init thread confirmed (pink_trace.txt updated).");
        else
            Log("Trace beacon not seen yet — advanced past attach is normal on first load.");
    }

    Log("Done. In-game: INSERT to open the executor menu, F9 for the embedded resource.");
    return 0;
}