# 420-Services — FiveM Cheat (Resource Embed + FULL EXE)

Rebuilt from the leaked source. **Single-file delivery** — the loader EXE carries
the cheat DLL inside it and manual-maps it into the game. Nothing is dropped to
disk, nothing appears in the target's module list.

| Artifact | Path | Size |
|---|---|---|
| Full loader EXE (embedded DLL + mapper + Lua resource) | `Release\420Loader.exe` | ~1.5 MB |
| Standalone cheat DLL (for `-dll` / `-inject` use) | `Release\cn.dll` | ~1.4 MB |

Also shipped: the embedded 420-Services Lua resource (`Resource\resource.lua`),
its generated C-array (`Resource\embedded_resource.h`), the embed manager
(`Resource\resource_embed.cpp/.h`), the manual mapper ([`Loader\manual_map.cpp`](Loader\manual_map.cpp),
[`Loader\shellcode.cpp`](Loader\shellcode.cpp)), the embedded DLL array
(`Loader\embedded_dll.h`), and the loader entry ([`Loader\loader.cpp`](Loader\loader.cpp)).
Both Visual Studio projects are self-contained — every include and library is
vendored in-tree, no DirectX SDK or freetype install required.

---

## What was added to the source

1. **Resource Embed** — the Lua feature resource is baked into `cn.dll` as a
   byte array. `ResourceEmbed::Start()` (wired into `dllmain.cpp` after
   `InitLuaExec`) waits for the captured FiveM Lua state to become live
   (180 s timeout, thread-waits, no frame stutter), then executes the
   embedded script through `DirectLuaExecEx` (CreateThreadNow wrap → full
   scheduler integration: `Wait`, events, commands). The executor menu shows
   live status: waiting / executed / failed, with a **Run now** button (page 0,
   "Embedded" row).

2. **FULL EXE (single file)** — `420Loader.exe`:
   - the cheat DLL is **embedded** in the EXE (`Loader\embedded_dll.h`)
   - **manual-maps** it into the target: in-target shellcode resolves imports
     against the already-loaded system DLLs, applies base relocations with the
     runtime delta, then calls `DllMain(DLL_PROCESS_ATTACH)` — no DLL file ever
     exists on disk, the image never appears in the module list
   - mapper payload is a self-contained PIC section (`.scode`, 1.1 KB),
     verified byte-level: zero RIP-relative data refs, zero absolute immediates
   - final section protections are tightened after entry runs (RWX staging →
     per-section attributes), only 5 system-DLL imports — all present in any
     GTA5.exe
   - auto-waits for `GTA5.exe` (timeout configurable, default 900 s)
   - `-launch` starts FiveM (local install path, falls back to `FiveM://` protocol)
   - verifies via the entry point's return (DllMain TRUE) + the cheat's own
     `pink_trace.txt` attach beacon
   - enables `SeDebugPrivilege` when possible; rejects 32-bit targets
   - logs everything to console + `loader.log` next to the exe

## Usage

```
release> 420Loader.exe                 # wait for game, manual-map the embedded DLL
release> 420Loader.exe -launch         # start FiveM, then auto-map when the game spawns
release> 420Loader.exe -dll D:\cn.dll  # manual-map an external DLL file instead
release> 420Loader.exe -inject D:\cn.dll  # legacy LoadLibrary injection (module listed)
release> 420Loader.exe -pid 1234       # target a specific PID
release> 420Loader.exe -timeout 300    # max seconds to wait (default 900)
```

In-game:
- `INSERT` — open the executor menu (resource router + Lua editor/console)
- `F9` — open the embedded 420-Services menu (Self / Vehicle / Player / World)

The DLL self-initializes on load (own `InitThread`): hooks the present call,
installs the Lua execution engine, then loads the embedded resource. Runtime
trace goes to `%USERPROFILE%\Desktop\pink_trace.txt`, debug log to
`%TEMP%\Pink_debug.log`.

## Building

MSBuild 18 (VS 2026, v145 toolset) — both projects are Release x64:

```
msbuild Pink.vcxproj   /p:Configuration=Release /p:Platform=x64
msbuild Loader\Loader.vcxproj /p:Configuration=Release /p:Platform=x64
```

Both outputs land in `Release\` (`cn.dll` + `420Loader.exe`). The loader's
`-dll`/`-inject` modes use the external `cn.dll`; the default runs the embedded
copy, so the EXE alone is the whole delivery.

To regenerate the embedded arrays after editing source files, re-run the two
byte-array generators (PowerShell) that produced `Resource\embedded_resource.h`
and `Loader\embedded_dll.h`, then rebuild.

## Per-build derivation notes (live target)

- The Lua executor depends on patterns inside `citizen-scripting-lua.dll`
  (`Scanner.h` signatures in `lua_exec.cpp`). FiveM updates can shift these —
  re-pull the signatures from a freshly unpacked `citizen-scripting-lua.dll`
  when the executor stops resolving `RunFileInternal`.
- The resource manager interop (`Resources.cpp`, `cfx\`) scans
  `citizen-resources-core.dll` for the resource list + termination stubs and
  indexes offsets `0xF0`/`0x118` on the resource struct. Verify those offsets
  against the current build if resource enumeration returns nothing.
- `Address::Get()->Load()` resolves the swapchain / viewport / pools from
  game memory; the D3D11 present hook has a Steam-overlay fallback. If the
  overlay hook wins and the menu stops drawing, force the vtable path.
- Anticheat posture: the injection path is quiet-first. Image is staged RW (never
  RWX as a whole), its **PE headers are wiped in-target before imports resolve**,
  per-section protections are applied **before** `DllMain` runs, and the Lua capture
  hook **removes itself** a few hundred ms after it has the state, restoring
  `citizen-scripting-lua.dll`'s `.text` to its on-disk bytes.
- Dispatch: default is `CreateRemoteThread` into the mapped payload — verified
  end-to-end (header wipe, imports, relocs, section protections, `DllMain` TRUE).
  `-hijack` switches to an experimental sweep that runs the payload on an existing
  game thread instead of creating one; it is opt-in because a thread blocked in a
  kernel wait discards the rewritten `Rip` when its syscall returns, so the sweep
  can fail to start the payload and is not yet safe to use as the default.
- Residual signals that remain by design: the payload is still anonymous
  `MEM_PRIVATE` executable memory while it runs, the cheat spawns its own thread
  from that region after attach, and the menu needs a swapchain-vtable hook. Memory
  scanning AC that samples anonymous executable pages or thread start addresses can
  still see those. Treat this as reduced risk, not invisibility — a 14-day automated
  ban is the observed outcome of the pre-hardening build.

## Layout

```
Resource\resource.lua          # 420-Services Lua feature resource (source)
Resource\embedded_resource.h   # generated C array (baked into cn.dll)
Resource\resource_embed.cpp    # waits for Lua-ready, executes embedded script
Resource\resource_embed.h
Loader\loader.cpp              # full EXE: find/launch game, map embedded DLL, verify
Loader\manual_map.cpp/.h       # loader-side mapper: PE parse, remote staging, dispatch
Loader\shellcode.cpp/.h        # PIC payload: PEB walk, imports, relocs, entry call
Loader\embedded_dll.h          # generated C array of cn.dll (baked into the EXE)
Loader\Loader.vcxproj
Release\cn.dll                 # built cheat DLL (standalone / external use)
Release\420Loader.exe          # built single-file loader EXE
```