#pragma once
#include <string>

// Embedded-resource manager.
// Holds the 420-Services Lua resource (generated header), waits for the
// captured FiveM Lua state to become ready, then executes it inside the
// game runtime with scheduler integration (DirectLuaExecEx).
namespace ResourceEmbed
{
    enum class State
    {
        NotReady,   // lua state not captured yet / watcher waiting
        Executed,   // script ran successfully at least once
        Failed,     // script failed to execute
        Running,    // a run is in progress
    };

    // Kick off auto-load. Safe to call any time; internally waits for
    // IsLuaReady() with a timeout, then executes once. Idempotent unless
    // force=true.
    void Start(bool force = false);

    // Immediate run attempt (menu "Run now" button). Returns true on success.
    bool RunNow();

    State GetState();
    const char* GetStateName();

    // Last Lua error string (short), for the menu.
    const std::string& GetLastError();
}