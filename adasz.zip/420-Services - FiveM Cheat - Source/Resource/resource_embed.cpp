// language: C++, file: Resource/resource_embed.cpp, target: Windows 11, MSVC
// 420-Services embedded Lua resource loader.
#include "resource_embed.h"

#include "embedded_resource.h"
#include "../lua_exec.hpp"

#include <Windows.h>
#include <atomic>
#include <string>

namespace ResourceEmbed
{
    namespace
    {
        std::atomic<State>  s_state{ State::NotReady };
        std::atomic<bool>   s_autoStarted{ false };
        std::atomic<bool>   s_autoDone{ false };
        std::string         s_lastError;
        SRWLOCK             s_errorLock = SRWLOCK_INIT;

        void setError(const char* msg)
        {
            AcquireSRWLockExclusive(&s_errorLock);
            s_lastError = msg ? msg : "";
            ReleaseSRWLockExclusive(&s_errorLock);
        }

        bool runScript()
        {
            if (g_embeddedResourceSize == 0)
            {
                setError("embedded resource empty");
                return false;
            }

            std::string script(
                reinterpret_cast<const char*>(g_embeddedResource),
                g_embeddedResourceSize);

            // CreateThreadNow wrap: full scheduler integration (Wait, events).
            if (!DirectLuaExecEx(script, true))
            {
                setError("DirectLuaExecEx failed");
                return false;
            }
            setError("");
            return true;
        }

        // Watcher: blocks until the captured lua_State is live, then runs the
        // embedded script exactly once. Lua becomes ready only after the game
        // has spun up citizen-scripting-lua (i.e. in-session), so this polls
        // for up to kLuaReadyTimeoutMs.
        DWORD WINAPI WatchThread(LPVOID)
        {
            constexpr DWORD kLuaReadyTimeoutMs = 180000; // 3 min
            const DWORD start = GetTickCount();

            while (!IsLuaReady())
            {
                if (GetTickCount() - start > kLuaReadyTimeoutMs)
                {
                    s_state.store(State::Failed);
                    setError("timed out waiting for Lua state");
                    s_autoDone.store(true);
                    return 1;
                }
                Sleep(250);
            }

            s_state.store(State::Running);
            const bool ok = runScript();
            s_state.store(ok ? State::Executed : State::Failed);
            s_autoDone.store(true);
            return ok ? 0 : 1;
        }
    }

    void Start(bool force)
    {
        // Once auto-load has completed (success or failure) a manual run via
        // the menu is still possible, but the automatic watcher must not
        // double-fire unless the caller explicitly asks for it.
        if (!force && s_autoStarted.exchange(true))
            return;

        if (!force && s_autoDone.load())
            return;

        if (IsLuaReady())
        {
            s_state.store(State::Running);
            const bool ok = runScript();
            s_state.store(ok ? State::Executed : State::Failed);
            s_autoDone.store(true);
            return;
        }

        // Not ready yet — spawn watcher.
        s_state.store(State::NotReady);
        HANDLE h = CreateThread(nullptr, 0, WatchThread, nullptr, 0, nullptr);
        if (h)
            CloseHandle(h);
        else
        {
            s_state.store(State::Failed);
            setError("failed to create watcher thread");
            s_autoDone.store(true);
        }
    }

    bool RunNow()
    {
        if (!IsLuaReady())
        {
            setError("Lua not ready");
            return false;
        }
        s_state.store(State::Running);
        const bool ok = runScript();
        s_state.store(ok ? State::Executed : State::Failed);
        return ok;
    }

    State GetState() { return s_state.load(); }

    const char* GetStateName()
    {
        switch (s_state.load())
        {
        case State::NotReady: return "waiting for Lua";
        case State::Executed: return "executed";
        case State::Failed:   return "failed";
        case State::Running:  return "running";
        }
        return "?";
    }

    const std::string& GetLastError()
    {
        static std::string empty;
        AcquireSRWLockShared(&s_errorLock);
        const std::string& r = s_lastError.empty() ? empty : s_lastError;
        ReleaseSRWLockShared(&s_errorLock);
        return r;
    }
}