--[[
  420-Services — embedded FiveM Lua resource
  Self-contained client feature module. Runs either as a normal resource
  (drop into resources) or embedded in the cheat DLL and executed on the
  captured Lua state via DirectLuaExecEx. No external dependencies.
]]
local version = "2.1.0"

-----------------------------------------------------------------------------
-- CONFIG
-----------------------------------------------------------------------------
local config = {
    openKey      = 296,    -- F9 (288=F1 .. 296=F9 .. 299=F12)
    menuTitle    = "420-Services",
    noclipSpeed  = 1.0,
    boostKph     = 40.0,   -- vehicle boost per press
    showSpeedo   = true,
}

-- input control ids (INPUT_* group 0)
local controls = {
    FRONTEND_UP     = 172,
    FRONTEND_DOWN   = 173,
    FRONTEND_LEFT   = 174,
    FRONTEND_RIGHT  = 175,
    FRONTEND_ACCEPT = 201,
    FRONTEND_CANCEL = 202,
    MOVE_FWD        = 32,  -- W
    MOVE_BWD        = 33,  -- S
    MOVE_LEFT       = 34,  -- A
    MOVE_RIGHT      = 35,  -- D
    JUMP            = 22,  -- Space
    DUCK            = 36,  -- Ctrl
    SPRINT          = 21,  -- Shift
}
local CONTROL = 0

-----------------------------------------------------------------------------
-- STATE
-----------------------------------------------------------------------------
local state = {
    open = false,
    tab  = 1,
    sel  = 1,
}

local tabs = { "Self", "Vehicle", "Player", "World" }

local toggles = {
    god          = false,
    noclip       = false,
    invisible    = false,
    superJump    = false,
    fastRun      = false,
    stamina      = false,
    ragdoll      = false,
    noFallDamage = false,
    vehGod       = false,
    seatbelt     = false,
    freezeTime   = false,
}

-----------------------------------------------------------------------------
-- HELPERS
-----------------------------------------------------------------------------
local function notify(msg)
    pcall(function()
        SetNotificationTextEntry("STRING")
        AddTextComponentSubstringPlayerName(tostring(msg))
        DrawNotification(false, true)
    end)
end

local function getPed()
    return PlayerPedId()
end

local function getVeh()
    local ped = getPed()
    if IsPedInAnyVehicle(ped, false) then
        return GetVehiclePedIsIn(ped, false)
    end
    return 0
end

local function requestControl(entity)
    local tries = 0
    while not NetworkHasControlOfEntity(entity) and tries < 40 do
        NetworkRequestControlOfEntity(entity)
        tries = tries + 1
        Wait(10)
    end
end

local function drawText(text, x, y, scale, r, g, b, a)
    pcall(function()
        SetTextFont(4)
        SetTextScale(scale, scale)
        SetTextColour(r, g, b, a)
        SetTextOutline()
        SetTextCentre(false)
        BeginTextCommandDisplayText("STRING")
        AddTextComponentSubstringPlayerName(tostring(text))
        EndTextCommandDisplayText(x, y)
    end)
end

local function drawRect(x, y, w, h, r, g, b, a)
    pcall(function() DrawRect(x, y, w, h, r, g, b, a) end)
end

local function drawMenuBox(w, h, x, y, title)
    drawRect(x + w / 2, y + h / 2, w, h, 0, 0, 0, 185)
    drawRect(x + w / 2, y + 10, w, 22, 220, 40, 80, 220)
    drawText(title, x + 4, y + 3, 0.34, 255, 255, 255, 255)

    local tabW = w / #tabs
    for i, t in ipairs(tabs) do
        local active = (i == state.tab)
        local color = active and { 220, 40, 80, 255 } or { 255, 255, 255, 200 }
        drawRect(x + (i - 0.5) * tabW, y + 30, tabW - 2, 16,
                 color[1], color[2], color[3], color[4])
        drawText(t, x + (i - 1) * tabW + 4, y + 27, 0.26, 255, 255, 255, 255)
    end
end

-----------------------------------------------------------------------------
-- CAMERA VECTORS (no native for cam forward, derive from rotation)
-----------------------------------------------------------------------------
local function camForwardRight()
    local rot = GetGameplayCamRot(2)  -- pitch, roll, yaw (deg)
    local yaw  = math.rad(rot.z)
    local pitch = math.rad(rot.x)
    local fwd = vector3(
        -math.sin(yaw) * math.cos(pitch),
         math.cos(yaw) * math.cos(pitch),
         math.sin(pitch))
    local right = vector3(math.cos(yaw), math.sin(yaw), 0)
    return fwd, right
end

-----------------------------------------------------------------------------
-- FEATURES (SELF)
-----------------------------------------------------------------------------
local function tickSelf()
    local ped = getPed()
    local player = PlayerId()

    SetEntityInvincible(ped, toggles.god)
    SetPlayerInvincible(player, toggles.god)

    SetEntityVisible(ped, not toggles.invisible, false)
    SetPedCanBeTargeted(ped, not toggles.invisible)

    SetPedCanRagdoll(ped, not toggles.ragdoll)
    SetPedConfigFlag(ped, 277, toggles.noFallDamage)  -- no falling damage
    SetPedConfigFlag(ped, 65, false)                  -- ensure water-walk off

    SetPedMoveRateOverride(ped, toggles.fastRun and 1.6 or 1.0)

    if toggles.stamina then
        ResetPlayerStamina(player)
    end

    if toggles.superJump and IsControlJustPressed(CONTROL, controls.JUMP) then
        local v = GetEntityVelocity(ped)
        SetEntityVelocity(ped, v.x, v.y, v.z + 5.0)
    end
end

-----------------------------------------------------------------------------
-- NOCLIP
-----------------------------------------------------------------------------
local function tickNoclip()
    local ped = getPed()
    if not toggles.noclip then return end

    local camPos = GetGameplayCamCoord()
    local fwd, right = camForwardRight()
    local speed = config.noclipSpeed

    local move = vector3(0, 0, 0)
    if IsControlPressed(CONTROL, controls.MOVE_FWD)   then move = move + fwd end
    if IsControlPressed(CONTROL, controls.MOVE_BWD)   then move = move - fwd end
    if IsControlPressed(CONTROL, controls.MOVE_LEFT)  then move = move - right end
    if IsControlPressed(CONTROL, controls.MOVE_RIGHT) then move = move + right end
    if IsControlPressed(CONTROL, controls.JUMP)       then move = move + vector3(0, 0, 1) end
    if IsControlPressed(CONTROL, controls.DUCK)       then move = move - vector3(0, 0, 1) end
    if IsControlPressed(CONTROL, controls.SPRINT)     then speed = speed * 2.0 end

    if move.x ~= 0 or move.y ~= 0 or move.z ~= 0 then
        local dest = camPos + move * speed
        requestControl(ped)
        SetEntityCoordsNoOffset(ped, dest.x, dest.y, dest.z, false, false, false)
        SetEntityHeading(ped, GetGameplayCamRot(2).z)
        FreezeEntityPosition(ped, true)
    else
        FreezeEntityPosition(ped, false)
    end
end

-----------------------------------------------------------------------------
-- FEATURES (VEHICLE)
-----------------------------------------------------------------------------
local function tickVehicle()
    local veh = getVeh()
    if veh == 0 then return end

    if toggles.vehGod then
        SetVehicleInvincible(veh, true)
        SetVehicleCanBeTargeted(veh, false)
        SetEntityCollision(veh, true, true)
        SetVehicleEngineHealthy(veh, true)
    end

    SetPedConfigFlag(getPed(), 32, toggles.seatbelt)
end

-----------------------------------------------------------------------------
-- SPEEDOMETER
-----------------------------------------------------------------------------
local function tickSpeedo()
    if not config.showSpeedo then return end
    local veh = getVeh()
    if veh == 0 then return end
    local speed = GetEntitySpeed(veh) * 3.6
    drawText(string.format("%.0f km/h", speed), 0.72, 0.88, 0.55, 255, 255, 255, 255)
end

-----------------------------------------------------------------------------
-- MAIN LOOP
-----------------------------------------------------------------------------
local frozenHour = -1

Citizen.CreateThread(function()
    pcall(function()
        RegisterCommand("420", function()
            state.open = not state.open
        end, false)
    end)

    while true do
        Wait(0)

        if IsControlJustPressed(CONTROL, config.openKey) then
            state.open = not state.open
            state.sel = 1
            state.tab = 1
        end

        tickSelf()
        tickNoclip()
        tickVehicle()
        tickSpeedo()

        if toggles.freezeTime then
            local h = GetClockHours()
            if h ~= frozenHour then
                frozenHour = h
                pcall(function() SetClockTime(h, GetClockMinutes(), GetClockSeconds()) end)
            end
        end
    end
end)

-----------------------------------------------------------------------------
-- MENU THREAD
-----------------------------------------------------------------------------
Citizen.CreateThread(function()
    while true do
        Wait(0)
        if state.open then
            local w = 300
            local x = 40
            local y = math.floor(GetScreenResolutionX() * 0.10)

            -- items for the current tab
            local items
            if state.tab == 1 then
                items = {
                    { "Godmode",          "toggle", "god" },
                    { "Noclip",           "toggle", "noclip" },
                    { "Invisible",        "toggle", "invisible" },
                    { "Super Jump",       "toggle", "superJump" },
                    { "Fast Run",         "toggle", "fastRun" },
                    { "Infinite Stamina", "toggle", "stamina" },
                    { "No Ragdoll",       "toggle", "ragdoll" },
                    { "No Fall Damage",   "toggle", "noFallDamage" },
                }
            elseif state.tab == 2 then
                items = {
                    { "Vehicle Godmode", "toggle", "vehGod" },
                    { "Repair Vehicle",  "action", function()
                        local v = getVeh()
                        if v == 0 then notify("Not in a vehicle") return end
                        SetVehicleFixed(v)
                        SetVehicleDirtLevel(v, 0.0)
                        notify("Vehicle repaired")
                    end },
                    { "Boost (+" .. config.boostKph .. " km/h)", "action", function()
                        local v = getVeh()
                        if v == 0 then notify("Not in a vehicle") return end
                        local target = GetEntitySpeed(v) * 3.6 + config.boostKph
                        SetVehicleForwardSpeed(v, target / 3.6)
                        notify("Boost")
                    end },
                    { "Flip Vehicle", "action", function()
                        local v = getVeh()
                        if v == 0 then notify("Not in a vehicle") return end
                        SetVehicleOnGroundProperly(v)
                        notify("Flipped")
                    end },
                    { "Delete Vehicle", "action", function()
                        local v = getVeh()
                        if v == 0 then notify("Not in a vehicle") return end
                        SetEntityAsMissionEntity(v, true, true)
                        DeleteVehicle(v)
                        notify("Deleted")
                    end },
                    { "Seatbelt", "toggle", "seatbelt" },
                }
            elseif state.tab == 3 then
                items = {
                    { "Teleport to Waypoint", "action", function()
                        local blip = GetFirstBlipInfoId(8)
                        if blip == 0 then notify("No waypoint set") return end
                        local c = GetBlipInfoIdCoord(blip)
                        local z = c.z
                        pcall(function()
                            local found, gz = GetGroundZFor_3DCoord(c.x, c.y, c.z, 0.0, false)
                            if found and gz ~= 0 then z = gz + 1.0 end
                        end)
                        SetEntityCoords(getPed(), c.x, c.y, z, false, false, false, true)
                        notify("Teleported")
                    end },
                    { "Heal + Armour", "action", function()
                        local ped = getPed()
                        SetEntityHealth(ped, GetEntityMaxHealth(ped))
                        SetPedArmour(ped, 100)
                        notify("Healed")
                    end },
                    { "Clear Wanted", "action", function()
                        pcall(function() SetPlayerWantedLevel(PlayerId(), 0) end)
                        notify("Wanted cleared")
                    end },
                    { "Give All Weapons", "action", function()
                        local ped = getPed()
                        for _, w in ipairs({
                            "WEAPON_PISTOL", "WEAPON_ASSAULTRIFLE", "WEAPON_SMG",
                            "WEAPON_SHOTGUN", "WEAPON_SNIPERRIFLE", "WEAPON_RPG",
                            "WEAPON_KNIFE", "WEAPON_GRENADE" }) do
                            GiveWeaponToPed(ped, GetHashKey(w), 9999, false, true)
                        end
                        notify("Weapons given")
                    end },
                    { "Suicide", "action", function()
                        SetEntityHealth(getPed(), 0)
                    end },
                }
            else
                items = {
                    { "Freeze Time", "toggle", "freezeTime" },
                    { "Weather: Clear", "action", function()
                        pcall(function() SetWeatherTypeNowPersist("EXTRASUNNY") end)
                        notify("Weather: clear")
                    end },
                    { "Weather: Rain", "action", function()
                        pcall(function() SetWeatherTypeNowPersist("RAIN") end)
                        notify("Weather: rain")
                    end },
                    { "Reset Weather", "action", function()
                        pcall(function()
                            ClearWeatherTypePersist()
                            SetWeatherTypeNowPersist("CLEAR")
                        end)
                        notify("Weather reset")
                    end },
                    { "Time: Sunrise", "action", function()
                        pcall(function() SetClockTime(6, 0, 0) end)
                    end },
                    { "Time: Noon", "action", function()
                        pcall(function() SetClockTime(12, 0, 0) end)
                    end },
                    { "Time: Midnight", "action", function()
                        pcall(function() SetClockTime(0, 0, 0) end)
                    end },
                }
            end

            if state.sel > #items then state.sel = #items end

            local h = 46 + #items * 22
            drawMenuBox(w, h, x, y, config.menuTitle)

            local iy = y + 46
            for i, item in ipairs(items) do
                local selected = (i == state.sel)
                if selected then
                    drawRect(x + w / 2, iy + 10, w - 4, 20, 220, 40, 80, 200)
                end
                local label = item[1]
                if item[2] == "toggle" then
                    label = label .. "  [" .. (toggles[item[3]] and "ON" or "OFF") .. "]"
                end
                drawText(label, x + 4, iy, 0.26, 255, 255, 255, 255)
                iy = iy + 22
            end

            drawText("ENTER: use  |  LEFT/RIGHT: tab  |  F9: close",
                     x + 4, y + h + 2, 0.22, 200, 200, 200, 255)

            -- input
            if IsControlJustPressed(CONTROL, controls.FRONTEND_LEFT) then
                state.tab = state.tab - 1
                if state.tab < 1 then state.tab = #tabs end
                state.sel = 1
            end
            if IsControlJustPressed(CONTROL, controls.FRONTEND_RIGHT) then
                state.tab = state.tab % #tabs + 1
                state.sel = 1
            end
            if IsControlJustPressed(CONTROL, controls.FRONTEND_DOWN) then
                state.sel = math.min(state.sel + 1, #items)
            end
            if IsControlJustPressed(CONTROL, controls.FRONTEND_UP) then
                state.sel = math.max(state.sel - 1, 1)
            end
            if IsControlJustPressed(CONTROL, controls.FRONTEND_ACCEPT) then
                local item = items[state.sel]
                if item then
                    if item[2] == "toggle" then
                        toggles[item[3]] = not toggles[item[3]]
                        notify(item[1] .. ": " .. (toggles[item[3]] and "ON" or "OFF"))
                    elseif item[2] == "action" then
                        pcall(item[3])
                    end
                end
            end
            if IsControlJustPressed(CONTROL, controls.FRONTEND_CANCEL) then
                state.open = false
            end
        end
    end
end)

return true