#include "Main/includes/includes.h"

#include "Cheat/Menu.h"
#include "lua_exec.hpp"
#include "SteamOverlayHook.h"

#include "Resource/resource_embed.h"

#include "Main/encrypt/skStr.h"
#include <string>

extern "C" __declspec(dllexport) int UhqHook(int code, WPARAM wParam, LPARAM lParam) { return CallNextHookEx(NULL, code, wParam, lParam); }

bool init = false;
LONG_PTR origWndProc = 0;
HWND hwnd = nullptr;

// Base of our manual-mapped image (DllMain hMod). Used to express fault
// addresses as RVAs so a crash site maps to a function in cn.dll.
uintptr_t g_dllBase = 0;

// Backbuffer dimensions at RTV creation; the draw block compares each frame
// and recreates the RTV when the swapchain resizes.
uint32_t s_rtvW = 0;
uint32_t s_rtvH = 0;

// Forward declarations
static void WriteMarker(const char* msg);
LRESULT CALLBACK WndProcHook(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
static void LogFaultRip(const char* tag, DWORD code, void* addr, void* rip);
static int CaptureFault(EXCEPTION_POINTERS* ep);


HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);


BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved);

LRESULT CALLBACK WndProcHook(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	// This runs on the message loop thread whenever a window message arrives.
	// If ImGui is half-initialized (init faulted), ImGui_ImplWin32_WndProcHandler
	// or GetIO() can fault — an unhandled fault HERE kills FiveM (USER32 dispatch).
	// Guard the whole handler; on fault, fall through to the original proc.
	__try
	{
		ImGui_ImplWin32_WndProcHandler(hwnd, uMsg, wParam, lParam);

		ImGuiIO& io = ImGui::GetIO();
		if (globals.menu_settings.block_input && (io.WantCaptureMouse || io.WantCaptureKeyboard))
		{
			return 1;
		}


		if (origWndProc)
		{
			return (LRESULT)CallWindowProc(reinterpret_cast<WNDPROC>(origWndProc), hwnd, uMsg, wParam, lParam);
		}
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		// ImGui state broken: skip input capture, pass the message through.
		if (origWndProc)
		{
			return (LRESULT)CallWindowProc(reinterpret_cast<WNDPROC>(origWndProc), hwnd, uMsg, wParam, lParam);
		}
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
}

bool hookApplied = false;


static void LogDebug(const std::string& msg)
{
	OutputDebugStringA(msg.c_str());
	char path[MAX_PATH + 1] = { 0 };
	if (GetTempPathA(MAX_PATH, path))
	{
		strcat_s(path, "Pink_debug.log");
		HANDLE hFile = CreateFileA(path, FILE_APPEND_DATA, FILE_SHARE_READ, NULL,
			OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			SYSTEMTIME st; GetLocalTime(&st);
			char buf[1024];
			int len = sprintf_s(buf, "[%02d:%02d:%02d.%03d] %s\r\n",
				st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, msg.c_str());
			if (len > 0) WriteFile(hFile, buf, (DWORD)len, NULL, NULL);
			CloseHandle(hFile);
		}
	}
}

static bool InstallVTablePresentHook()
{
	uint64_t pSwapChainAddr = Address::Get()->s_pSwapChain;
	if (!pSwapChainAddr)
	{
		LogDebug("[Pink] s_pSwapChain = 0");
		return false;
	}

	IDXGISwapChain* pSwapChain = *(IDXGISwapChain**)pSwapChainAddr;
	if (!pSwapChain)
	{
		LogDebug("[Pink] *s_pSwapChain = null");
		return false;
	}

	MEMORY_BASIC_INFORMATION mbi = {};
	if (!VirtualQuery(pSwapChain, &mbi, sizeof(mbi)) || mbi.State != MEM_COMMIT)
	{
		LogDebug("[Pink] s_pSwapChain invalide");
		return false;
	}

	void** vtable = *(void***)pSwapChain;
	if (!vtable || !vtable[8])
	{
		LogDebug("[Pink] vtable[8] null");
		return false;
	}

	oPresent = (Present)vtable[8];

	DWORD oldProtect = 0;
	if (!VirtualProtect(&vtable[8], sizeof(void*), PAGE_READWRITE, &oldProtect))
	{
		LogDebug("[Pink] VirtualProtect vtable[8] echoue");
		oPresent = nullptr;
		return false;
	}

	vtable[8] = hkPresent;
	VirtualProtect(&vtable[8], sizeof(void*), oldProtect, &oldProtect);

	LogDebug("[Pink] VTable Present hook OK");
	return true;
}


// The image is manual-mapped AND headerless by design: the payload wipes the
// MZ/PE signature bytes, but preserves e_lfanew (0x3C) and the optional header
// so the .pdata directory is still reachable here. Without RtlAddFunctionTable
// the first exception anywhere in the DLL (menu frame, hook, Lua exec) fails
// to unwind and kills the process with a bare-address crash.
static void RegisterModuleUnwind(HMODULE hMod)
{
    const BYTE* base = (const BYTE*)hMod;

    const DWORD e_lfanew = *(const DWORD*)(base + 0x3C);
    if (e_lfanew == 0 || e_lfanew >= 0x1000)
    {
        WriteMarker("RtlAddFunctionTable: e_lfanew invalide");
        return;
    }
    IMAGE_NT_HEADERS* nt = (IMAGE_NT_HEADERS*)(base + e_lfanew);

    const IMAGE_DATA_DIRECTORY& exc =
        nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
    if (!exc.VirtualAddress || !exc.Size)
    {
        WriteMarker("RtlAddFunctionTable: no .pdata");
        return;
    }

    BOOL ok = RtlAddFunctionTable(
        (PRUNTIME_FUNCTION)(base + exc.VirtualAddress),
        exc.Size / sizeof(RUNTIME_FUNCTION),
        (DWORD64)hMod);
    WriteMarker(ok ? "RtlAddFunctionTable OK" : "RtlAddFunctionTable ECHEC");
}

static void WriteMarkerPure(const char* msg)
{
	char path[MAX_PATH + 1] = { 0 };
	if (GetEnvironmentVariableA("USERPROFILE", path, MAX_PATH))
	{
		int i = 0;
		while (path[i]) i++;
		const char* suffix = "\\Desktop\\pink_trace.txt";
		int j = 0;
		while (suffix[j] && i < MAX_PATH) path[i++] = suffix[j++];
		path[i] = 0;

		HANDLE hFile = CreateFileA(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			SYSTEMTIME st; GetLocalTime(&st);
			char buf[512];
			int pos = 0;
			buf[pos++] = '[';
			buf[pos++] = '0' + (st.wHour / 10);
			buf[pos++] = '0' + (st.wHour % 10);
			buf[pos++] = ':';
			buf[pos++] = '0' + (st.wMinute / 10);
			buf[pos++] = '0' + (st.wMinute % 10);
			buf[pos++] = ':';
			buf[pos++] = '0' + (st.wSecond / 10);
			buf[pos++] = '0' + (st.wSecond % 10);
			buf[pos++] = ']';
			buf[pos++] = ' ';
			const char* p = msg;
			while (*p && pos < 500) buf[pos++] = *p++;
			buf[pos++] = '\r';
			buf[pos++] = '\n';
			WriteFile(hFile, buf, (DWORD)pos, NULL, NULL);
			CloseHandle(hFile);
		}
	}
}

static DWORD WINAPI InitThread(LPVOID)
{
	WriteMarkerPure("InitThread ALIVE (pure Win32)");

	__try {
		Sleep(100);
		WriteMarkerPure("InitThread after Sleep(100)");

		WriteMarkerPure("Address::Load begin");
		Address::Get()->Load();
		WriteMarkerPure("Address::Load OK");

		WriteMarkerPure("InitLuaExec begin");
		InitLuaExec();
		WriteMarkerPure("InitLuaExec OK");

		WriteMarkerPure("ResourceEmbed begin");
		ResourceEmbed::Start();
		WriteMarkerPure("ResourceEmbed OK");

		WriteMarkerPure("SteamHook begin");
		HMODULE hOverlay = GetModuleHandleA("GameOverlayRenderer64.dll");
		bool steamOk = false;
		if (hOverlay)
		{
			steamOk = SteamHook::Install(hOverlay);
			WriteMarkerPure(steamOk ? "SteamHook OK" : "SteamHook ECHEC");
		}
		else
		{
			WriteMarkerPure("SteamHook: GameOverlayRenderer64 pas charge");
		}

		if (!steamOk)
		{
			WriteMarkerPure("VTable fallback begin");
			bool vtableOk = InstallVTablePresentHook();
			WriteMarkerPure(vtableOk ? "VTable fallback OK" : "VTable fallback ECHEC");
		}

		WriteMarkerPure("InitThread FINI");
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		DWORD code = GetExceptionCode();
		char exBuf[64] = "InitThread EXCEPTION: 0x";
		const char hex[] = "0123456789ABCDEF";
		int p = 24; 
		for (int shift = 28; shift >= 0; shift -= 4)
			exBuf[p++] = hex[(code >> shift) & 0xF];
		exBuf[p] = 0;
		WriteMarkerPure(exBuf);
	}

	return 0;
}

void InstallHook()
{
	hwnd = window;
	hookApplied = false;

	LONG_PTR WindowLongPtrW = GetWindowLongPtrW(hwnd, GWLP_WNDPROC);
	if (!WindowLongPtrW)
		return;

	// Preferred path: the window proc is a `48 B8 imm64` thunk (mov rax,
	// imm64) — patch the embedded target in place. Guarded + VirtualProtect:
	// the thunk can live in read-only memory, and a fault here must never
	// take init down. Fall back to SetWindowLongPtrW on any failure.
	bool patchOk = false;
	__try
	{
		if (*reinterpret_cast<BYTE*>(WindowLongPtrW) == 0x48 &&
			*reinterpret_cast<BYTE*>(WindowLongPtrW + 1) == 0xB8)
		{
			DWORD oldProtect = 0;
			if (VirtualProtect(reinterpret_cast<LPVOID>(WindowLongPtrW + 2), sizeof(LONG_PTR), PAGE_READWRITE, &oldProtect))
			{
				origWndProc = *reinterpret_cast<LONG_PTR*>(WindowLongPtrW + 2);
				*reinterpret_cast<LONG_PTR*>(WindowLongPtrW + 2) = reinterpret_cast<LONG_PTR>(WndProcHook);
				VirtualProtect(reinterpret_cast<LPVOID>(WindowLongPtrW + 2), sizeof(LONG_PTR), oldProtect, &oldProtect);
				hookApplied = true;
				patchOk = true;
			}
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER)
	{
		// fall through to the SetWindowLongPtrW path
	}

	if (!patchOk)
	{
		LONG_PTR prev = SetWindowLongPtrW(hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(WndProcHook));
		if (prev != 0)
		{
			origWndProc = prev;
			hookApplied = true;
		}
	}
}

static void RunFeatureLoop() {

	if ((GetAsyncKeyState(globals.menu.hotkey.key) & 1) || (GetAsyncKeyState(VK_INSERT) & 1)) {
		globals.menu.opened = !globals.menu.opened;
	}


	if (globals.menu.unload_requested && !globals.menu.unloaded) {
		globals.menu.opened = false;
		globals.menu.unloaded = true;
	}

	if (!globals.menu.unloaded) {
		Menu::Get()->Load();
	}
}

// Snapshot fault details in the __except FILTER (POD only), then write them
// from the handler via LogFaultRip. Rip localizes the exact faulting function.
static volatile void* s_faultAddr = nullptr;
static volatile void* s_faultRip = nullptr;
static volatile DWORD s_faultCode = 0;
static int CaptureFault(EXCEPTION_POINTERS* ep)
{
	if (ep && ep->ExceptionRecord)
	{
		s_faultCode = ep->ExceptionRecord->ExceptionCode;
		s_faultAddr = ep->ExceptionRecord->ExceptionAddress;
	}
	if (ep && ep->ContextRecord)
		s_faultRip = (void*)ep->ContextRecord->Rip;
	return EXCEPTION_EXECUTE_HANDLER;
}

static void OnFrameSafe() {
	__try {
		RunFeatureLoop();
	}
	__except (CaptureFault(GetExceptionInformation())) {
		// A fault inside the menu draw (usually a game-memory read in a tab
		// page) leaves ImGui's stacks unbalanced. Recover so the next frame
		// starts clean instead of EndFrame asserting and killing the process.
		static volatile LONG s_logged = 0;
		if (InterlockedExchange(&s_logged, 1) == 0)
		{
			LogFaultRip("FRAME FAULT", s_faultCode, (void*)s_faultAddr, (void*)s_faultRip);
		}
		__try {
			ui::recover_after_exception();
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			// Recovery itself faulted (ImGui half-initialized). Swallow it;
			// the display is already broken, the process must survive.
		}
	}
}

// Present-hook init diagnostics. On a present fault, the last step marker in
// pink_trace localizes which init call faulted (P0 GetDevice ... P9 ready).
static volatile LONG s_presentStep = -1;
static void MarkPresentStep(int step)
{
	if (InterlockedCompareExchange(&s_presentStep, step, step - 1) == step - 1)
	{
		static const char* const kStepNames[] = {
			"P0 getdevice", "P1 getctx", "P2 getdesc", "P3 getbuffer",
			"P4 rtview", "P5 hook", "P6 imgui", "P7 dx11", "P8 win32", "P9 ready"
		};
		WriteMarkerPure(kStepNames[step]);
	}
}

// If the one-time init faults repeatedly, stop retrying: an endless
// fault+recover loop every frame corrupts state and kills the process later.
static volatile LONG s_presentInitFaults = 0;
static volatile LONG s_initDead = 0;

static void hkPresentInternal(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	if (!init)
	{
		if (s_initDead)
			return;

		MarkPresentStep(0);
		if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&pDevice)))
		{
			if (!pDevice) return;

			MarkPresentStep(1);
			pDevice->GetImmediateContext(&pContext);
			if (!pContext) return;

			MarkPresentStep(2);
			DXGI_SWAP_CHAIN_DESC sd;
			pSwapChain->GetDesc(&sd);
			window = sd.OutputWindow;
			if (!window) return;

			MarkPresentStep(3);
			ID3D11Texture2D* pBackBuffer = nullptr;
			if (FAILED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer)) || !pBackBuffer)
				return;

			MarkPresentStep(4);
			if (FAILED(pDevice->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView)) || !mainRenderTargetView) {
				pBackBuffer->Release();
				return;
			}
			pBackBuffer->Release();

			// Record the backbuffer size so the per-frame draw block can detect
			// a swapchain resize and recreate the RTV instead of drawing to a
			// stale buffer (a d3d11.dll crash source).
			{
				DXGI_SWAP_CHAIN_DESC sd0;
				if (SUCCEEDED(pSwapChain->GetDesc(&sd0)))
				{
					s_rtvW = sd0.BufferDesc.Width;
					s_rtvH = sd0.BufferDesc.Height;
				}
			}

			MarkPresentStep(5);
			if (!hookApplied)
				InstallHook();

			MarkPresentStep(6);
			// ImGui bootstrap runs ONCE. If any step faults, mark init dead and
			// stop — retrying a half-built ImGui corrupts state further, and
			// the window-proc hook on a broken ImGui would kill the process.
			// This __try block has POD-only locals; C2712-safe.
			__try {
				Menu::Get()->LoadImGui();

				if (!ImGui::GetCurrentContext()) {
					InterlockedExchange(&s_initDead, 1);
					return;
				}

				ImGui_ImplDX11_Init(pDevice, pContext);
				MarkPresentStep(7);
				ImGui_ImplWin32_Init(window);
				MarkPresentStep(8);

				init = true;
				MarkPresentStep(9);
			}
			__except (EXCEPTION_EXECUTE_HANDLER) {
				InterlockedExchange(&s_initDead, 1);
				return;
			}
		}
		else {
			return;
		}
	}

	if (init && !globals.menu.unloaded) {
		// Which thread is the present hook on? Log once so we can see if the
		// overlay runs on the game's render thread (expected) or somewhere else.
		static volatile LONG s_tidLogged = 0;
		if (InterlockedExchange(&s_tidLogged, 1) == 0)
		{
			char tb[64];
			int tp = 0;
			const char tpre[] = "PRESENT THREAD 0x";
			for (int i = 0; tpre[i] && tp < 52; i++) tb[tp++] = tpre[i];
			DWORD tid = GetCurrentThreadId();
			static const char hx[] = "0123456789ABCDEF";
			for (int shift = 28; shift >= 0; shift -= 4) tb[tp++] = hx[(tid >> shift) & 0xF];
			tb[tp] = 0;
			WriteMarkerPure(tb);
		}

		// Grace period: do not touch D3D11 for the first ~15 presents. The game
		// is still settling; our font-atlas creation racing its own D3D11 calls
		// has crashed inside d3d11.dll. Present still runs (see oPresent below);
		// we just skip the overlay for these frames.
		static volatile LONG s_skipDraw = 15;
		if (s_skipDraw <= 0 || InterlockedDecrement(&s_skipDraw) < 0)
		{
			// Device lost/removed (alt-tab, driver reset, TDR): drawing now is
			// unsafe — every D3D11 call faults. Skip until the game recovers.
			HRESULT dr = pDevice ? pDevice->GetDeviceRemovedReason() : E_FAIL;
			if (dr != S_OK)
			{
				static volatile LONG s_drLogged = 0;
				if (InterlockedExchange(&s_drLogged, 1) == 0)
					WriteMarkerPure("DEVICE REMOVED - skipping draw");
			}
			else
			{
				// Swapchain resized? Recreate the RTV so we never draw to a
				// stale backbuffer (a classic d3d11.dll crash).
				DXGI_SWAP_CHAIN_DESC sdchk;
				if (SUCCEEDED(pSwapChain->GetDesc(&sdchk)) &&
					(sdchk.BufferDesc.Width != s_rtvW || sdchk.BufferDesc.Height != s_rtvH))
				{
					if (mainRenderTargetView) { mainRenderTargetView->Release(); mainRenderTargetView = nullptr; }
					ID3D11Texture2D* pBB2 = nullptr;
					if (SUCCEEDED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBB2)) && pBB2)
					{
						if (SUCCEEDED(pDevice->CreateRenderTargetView(pBB2, NULL, &mainRenderTargetView)))
						{
							s_rtvW = sdchk.BufferDesc.Width;
							s_rtvH = sdchk.BufferDesc.Height;
							static volatile LONG s_rLogged = 0;
							if (InterlockedExchange(&s_rLogged, 1) == 0)
								WriteMarkerPure("RTV RESIZED");
						}
						pBB2->Release();
					}
				}

				if (mainRenderTargetView)
				{
					// One-time phase markers: if the first drawn frame faults,
					// these tell us exactly which phase it died in.
					static volatile LONG s_a = 0, s_b = 0, s_c = 0;
					if (InterlockedExchange(&s_a, 1) == 0)
						WriteMarkerPure("PRESENT A nav");

					ImGui_ImplDX11_NewFrame();
					ImGui_ImplWin32_NewFrame();
					ImGui::NewFrame();

					__try {
						OnFrameSafe();
					}
					__except (EXCEPTION_EXECUTE_HANDLER) {

					}

					if (InterlockedExchange(&s_b, 1) == 0)
						WriteMarkerPure("PRESENT B features");

					ImGui::Render();

					ImDrawData* dd = ImGui::GetDrawData();
					if (dd && dd->CmdListsCount > 0 && mainRenderTargetView && pContext) {
						pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
						ImGui_ImplDX11_RenderDrawData(dd);
					}

					if (InterlockedExchange(&s_c, 1) == 0)
						WriteMarkerPure("PRESENT C rendered");
				}
			}
		}
	}
}

// If a present/frame fault fires, record the faulting RIP so the next trace
// pinpoints the exact function instead of leaving us guessing.
static volatile LONG s_ripLogged = 0;
static void LogFaultRip(const char* tag, DWORD code, void* addr, void* rip)
{
	if (InterlockedExchange(&s_ripLogged, 1) != 0)
		return;

	char buf[256];
	int p = 0;
	const char* t = tag;
	while (*t && p < 30) buf[p++] = *t++;
	buf[p++] = ' '; buf[p++] = '0'; buf[p++] = 'x';
	static const char hex[] = "0123456789ABCDEF";
	for (int shift = 28; shift >= 0; shift -= 4) buf[p++] = hex[(code >> shift) & 0xF];
	buf[p++] = ' '; buf[p++] = 'a'; buf[p++] = 't';
	buf[p++] = ' '; buf[p++] = '0'; buf[p++] = 'x';
	uintptr_t a = (uintptr_t)addr;
	for (int shift = 60; shift >= 0; shift -= 4) buf[p++] = hex[(a >> shift) & 0xF];
	buf[p++] = ' '; buf[p++] = 'r'; buf[p++] = 'i'; buf[p++] = 'p';
	buf[p++] = ' '; buf[p++] = '0'; buf[p++] = 'x';
	uintptr_t r = (uintptr_t)rip;
	for (int shift = 60; shift >= 0; shift -= 4) buf[p++] = hex[(r >> shift) & 0xF];

	// If the fault is inside our manual-mapped image, express it as an RVA
	// (rip - base) — that maps directly to a function in cn.dll.
	if (g_dllBase && r >= g_dllBase && r < g_dllBase + 0x400000)
	{
		buf[p++] = ' '; buf[p++] = 'r'; buf[p++] = 'v'; buf[p++] = 'a';
		buf[p++] = ' '; buf[p++] = '0'; buf[p++] = 'x';
		uintptr_t rva = r - g_dllBase;
		for (int shift = 44; shift >= 0; shift -= 4) buf[p++] = hex[(rva >> shift) & 0xF];
	}
	buf[p] = 0;
	WriteMarkerPure(buf);
}

HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	__try {
		if (pSwapChain) {
			hkPresentInternal(pSwapChain, SyncInterval, Flags);
		}
	}
	__except (CaptureFault(GetExceptionInformation())) {
		// One-time diagnostic so we can see if exceptions are firing inside the
		// hook and being swallowed — this is the whole point of the .pdata fix.
		static volatile LONG s_caughtOnce = 0;
		if (InterlockedExchange(&s_caughtOnce, 1) == 0)
		{
			LogFaultRip("PRESENT FAULT", s_faultCode, (void*)s_faultAddr, (void*)s_faultRip);
		}

		// A fault during the one-time init is not fatal; retry next frame.
		// But cap the retries: an endless fault+recover loop every frame
		// corrupts state and kills the process. After 30 faults, stop trying.
		if (!init && InterlockedIncrement(&s_presentInitFaults) >= 30)
			InterlockedExchange(&s_initDead, 1);

		// Restore ImGui balance no matter where the fault happened. The
		// recovery itself can fault when ImGui is half-initialized (e.g. a
		// context exists but NewFrame never ran) — never let that escape, an
		// unhandled exception here would kill the process.
		__try {
			ui::recover_after_exception();
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {
			// Give up quietly; the process must survive.
			if (!init && InterlockedIncrement(&s_presentInitFaults) >= 30)
				InterlockedExchange(&s_initDead, 1);
		}
	}

	HRESULT hr = oPresent ? oPresent(pSwapChain, SyncInterval, Flags) : E_FAIL;


	static long long s_qpc_freq = 0;
	static double s_last_sec = 0.0;
	static int s_frame_count = 0;
	static double s_last_counted_present = 0.0;
	if (s_qpc_freq == 0) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); s_qpc_freq = f.QuadPart; }

	LARGE_INTEGER c; QueryPerformanceCounter(&c);
	double now_sec = (double)c.QuadPart / (double)s_qpc_freq;
	const double min_dt = 1.0 / 300.0;
	if ((now_sec - s_last_counted_present) >= min_dt) {
		s_frame_count++;
		s_last_counted_present = now_sec;
	}
	if ((now_sec - s_last_sec) >= 0.5) {
		double fps = (double)s_frame_count / (now_sec - s_last_sec);
		g_last_present_fps = (int)(fps + 0.5);
		s_frame_count = 0;
		s_last_sec = now_sec;
	}

	return hr;
}



static void WriteMarker(const char* msg)
{
	char path[MAX_PATH + 1] = { 0 };
	if (GetEnvironmentVariableA("USERPROFILE", path, MAX_PATH))
	{
		strcat_s(path, "\\Desktop\\pink_trace.txt");
		HANDLE hFile = CreateFileA(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			SYSTEMTIME st; GetLocalTime(&st);
			char buf[512];
			int len = sprintf_s(buf, "[%02d:%02d:%02d.%03d] %s\r\n",
				st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, msg);
			if (len > 0) WriteFile(hFile, buf, (DWORD)len, NULL, NULL);
			CloseHandle(hFile);
		}
	}
}

BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved) {

	if (dwReason == DLL_PROCESS_ATTACH) {
		g_dllBase = (uintptr_t)hMod;
		RegisterModuleUnwind(hMod);
		WriteMarker("DLL_PROCESS_ATTACH");
		WriteMarker("DLL base 0x");
		char basebuf[32];
		int bp = 0;
		uintptr_t b = g_dllBase;
		static const char hexch[] = "0123456789ABCDEF";
		bool started = false;
		for (int shift = 60; shift >= 0; shift -= 4)
		{
			int nib = (int)((b >> shift) & 0xF);
			if (nib || started || shift == 0) { basebuf[bp++] = hexch[nib]; started = true; }
		}
		basebuf[bp] = 0;
		WriteMarker(basebuf);
		DisableThreadLibraryCalls(hMod);
		WriteMarker("After DisableThreadLibraryCalls");
		HANDLE h = CreateThread(NULL, 0, InitThread, NULL, 0, NULL);
		if (h)
		{
			WriteMarker("CreateThread OK");

			// Some hosts kill or never schedule threads whose entry point is not
			// in a registered image. Probe, and if the thread did not take, run
			// the init body on this thread instead — this one demonstrably runs.
			DWORD wr = WaitForSingleObject(h, 1200);
			DWORD code = 0;
			GetExitCodeThread(h, &code);
			const bool alive = (wr == WAIT_TIMEOUT) || (code == STILL_ACTIVE);

			char diag[96];
			int p = 0;
			const char* pre = alive
				? "InitThread running code=0x"
				: "InitThread died code=0x";
			for (int i = 0; pre[i] && p < 80; i++) diag[p++] = pre[i];
			for (int shift = 28; shift >= 0; shift -= 4)
			{
				int nib = (code >> shift) & 0xF;
				diag[p++] = (char)(nib < 10 ? '0' + nib : 'a' + nib - 10);
			}
			diag[p] = 0;
			WriteMarker(diag);

			CloseHandle(h);
			WriteMarker("CloseHandle OK");

			if (!alive)
			{
				WriteMarker("InitThread unusable - running init inline");
				InitThread(NULL);
				WriteMarker("Inline init returned");
			}
		}
		else
		{
			WriteMarker("CreateThread ECHEC! - running init inline");
			InitThread(NULL);
			WriteMarker("Inline init returned");
		}
	}

	return TRUE;
}
